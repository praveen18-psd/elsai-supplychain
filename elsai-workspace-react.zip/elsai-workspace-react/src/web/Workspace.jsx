import { useEffect, useRef } from 'react'
import { BellRing, MessageSquare, PanelLeft, PanelRight, Smartphone, SquarePen, Sun, Workflow as WorkflowIcon, X } from 'lucide-react'
import { Toast } from '../components/ui.jsx'
import { WorkspaceProvider, useWS } from './store.jsx'
import Briefing from './Briefing.jsx'
import Chat from './Chat.jsx'
import WorkflowView from './Workflow.jsx'
import Prefs from './Prefs.jsx'
import Rail from './Rail.jsx'
import Composer from './Composer.jsx'

const RECENT = [['Cantieri Alfa review', 'Tell me about Cantieri Alfa'], ['Haulage strike impact', 'What happens if the haulage strike goes ahead?'], ['Precast alternates', 'Find alternatives to Cantieri Alfa'], ['Theta Tunnel Services', 'Tell me about Theta Tunnel Services']]
const BRIEF_SUGGESTIONS = ['Which suppliers are getting riskier?', 'Where does this data come from?', 'Show me the agent trace']

function Sidebar() {
  const { s, ask, setView, newChat, openWorkflow, isBusy } = useWS()
  const go = (v) => { if (!isBusy) setView(v) }
  return (
    <aside className={`cside ${s.sideOpen ? 'open' : ''}`} aria-label="Workspace">
      <img className="logo-img" src="/elsai-logo.png" alt="elsai" />
      <label className="xs muted" htmlFor="projSel" style={{ padding: '0 8px' }}>Project</label>
      <select className="select sm" id="projSel" aria-label="Project" style={{ margin: '0 4px 8px', width: 'calc(100% - 8px)' }} defaultValue="lot4">
        <option value="lot4">Rail Tunnel Lot 4</option><option disabled>Metro Line B</option><option disabled>Valle Dam Spillway</option>
      </select>
      <button type="button" className="btn btn-outline btn-sm" style={{ justifyContent: 'flex-start' }} onClick={newChat}><SquarePen size={16} />New conversation</button>
      <button type="button" className="sb-item" aria-current={s.view === 'brief' ? 'page' : undefined} onClick={() => go('brief')}><Sun size={16} /><span>Morning briefing</span></button>
      <button type="button" className="sb-item" aria-current={s.view === 'workflow' ? 'page' : undefined} onClick={() => openWorkflow(null, '')}><WorkflowIcon size={16} /><span>Agent workflow</span></button>
      <button type="button" className="sb-item" aria-current={s.view === 'prefs' ? 'page' : undefined} onClick={() => go('prefs')}><BellRing size={16} /><span>Alerts &amp; devices</span></button>
      <a className="sb-item" href="#/devices" style={{ textDecoration: 'none' }}><Smartphone size={16} /><span>Mobile &amp; watch</span></a>
      <div className="sb-label">Recent</div>
      {RECENT.map(([t, q]) => <button type="button" key={t} className="recent" disabled={isBusy} onClick={() => ask(q)}>{t}</button>)}
      <div style={{ marginTop: 'auto' }} className="user"><span className="avatar">MB</span><span className="col"><span className="sm medium">Marco Bellini</span><span className="xs muted">Procurement Lead</span></span></div>
    </aside>
  )
}

function Sheet() {
  const { sheet, closeSheet } = useWS()
  return (
    <>
      {sheet && <div id="scrim" onClick={closeSheet} />}
      <aside id="sheet" className={sheet ? 'open' : ''} aria-hidden={!sheet} role="dialog" aria-modal="true" aria-labelledby="shTitle">
        <div className="sh-head">
          <div className="col g1"><span className="sh-title" id="shTitle">{sheet?.title}</span><span className="sm muted">{sheet?.desc}</span></div>
          <button type="button" className="btn btn-ghost btn-icon btn-sm" aria-label="Close" onClick={closeSheet}><X size={16} /></button>
        </div>
        <div className="sh-body">{sheet?.content}</div>
      </aside>
    </>
  )
}

function Shell() {
  const { s, mut, setView, toggleSide, toggleRail, openWorkflow, sheet, closeSheet, toastMsg, isBusy } = useWS()
  const scrollRef = useRef(null)
  const narrow = (w) => typeof window !== 'undefined' && window.innerWidth <= w
  const sidePressed = narrow(820) ? s.sideOpen : !s.sideOff
  const railPressed = narrow(1180) ? s.railOpen : !s.railOff
  const title = s.view === 'brief' ? 'Morning briefing' : s.view === 'workflow' ? 'Agent workflow' : s.view === 'prefs' ? 'Alerts & devices' : s.title || 'New conversation'

  useEffect(() => { if (s.view !== 'chat' && scrollRef.current) scrollRef.current.scrollTop = 0 }, [s.view])
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Escape') return
      if (sheet) closeSheet()
      else mut((n) => { n.railOpen = false; n.sideOpen = false })
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [sheet, closeSheet, mut])

  return (
    <div className={`capp ${s.sideOff ? 'side-off' : ''} ${s.railOff ? 'rail-off' : ''}`}>
      <Sidebar />
      <section className="cmain">
        <header className="chead">
          <button type="button" className="btn btn-ghost btn-icon btn-sm hbtn" aria-label="Show or hide sidebar" title="Sidebar" aria-pressed={sidePressed} onClick={toggleSide}><PanelLeft size={16} /></button>
          <span className="sep-v" aria-hidden="true" />
          <span className="ttl">{title}</span>
          <span className="live-dot" style={{ marginLeft: 8 }}>8 agents online</span>
          <span style={{ marginLeft: 'auto' }} className="row-2">
            {s.view !== 'chat' && s.msgs.length > 0 && <button type="button" className="btn btn-ghost btn-sm" disabled={isBusy} onClick={() => setView('chat')}><MessageSquare size={16} />Conversation</button>}
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => openWorkflow(null, '')}><WorkflowIcon size={16} /><span>Workflow</span></button>
            {s.view !== 'brief' && <button type="button" className="btn btn-ghost btn-sm" disabled={isBusy} onClick={() => setView('brief')}><Sun size={16} />Briefing</button>}
            <button type="button" className="btn btn-ghost btn-icon btn-sm hbtn" aria-label="Show or hide agent activity" title="Agent activity" aria-pressed={railPressed} onClick={toggleRail}><PanelRight size={16} /></button>
          </span>
        </header>
        <div className="cscroll" ref={scrollRef}>
          <div className="cinner">
            {s.view === 'brief' && <Briefing />}
            <div hidden={s.view !== 'chat'}><Chat scrollRef={scrollRef} /></div>
            {s.view === 'workflow' && <WorkflowView />}
            {s.view === 'prefs' && <Prefs />}
          </div>
        </div>
        <Composer suggestions={s.view === 'brief' ? BRIEF_SUGGESTIONS : []} />
      </section>
      <Rail />
      <Sheet />
      <Toast msg={toastMsg} />
    </div>
  )
}

export default function Workspace() {
  return <WorkspaceProvider><Shell /></WorkspaceProvider>
}
