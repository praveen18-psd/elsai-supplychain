import { ArrowRight } from 'lucide-react'
import { EXPOSURE, SUPPLIERS, scoreOf, trendOf } from '../lib/data.js'
import { lvlTone, money, riskLvl } from '../lib/format.js'
import { Badge, Spark } from '../components/ui.jsx'
import { useWS } from './store.jsx'

const ATTENTION = [
  ['bad', 'Supplier risk', 'Cantieri Alfa risk rose to 68', 'Was 41 in July. Credit rating cut, 12 days late on Metro Line B.', 'Why is Cantieri Alfa getting riskier?'],
  ['warn', 'Disruption', 'Haulage strike could stop the Metro Line B TBM', 'Strike 12–14 Oct. Segment batch 4 has a 2-day buffer.', 'What happens if the haulage strike goes ahead?'],
  ['neutral', 'Tender', 'TND-2026-014 award is waiting for the committee', '4 bids for 12,400 precast segments.', 'Compare the bids for TND-2026-014'],
]

export default function Briefing() {
  const { ask } = useWS()
  const watch = [...SUPPLIERS].sort((a, b) => scoreOf(b) - scoreOf(a)).slice(0, 5)
  const alfaExp = EXPOSURE.filter((e) => e.sub === 'Cantieri Alfa').reduce((s, e) => s + e.amt, 0)
  return (
    <div className="col g6">
      <div className="col g1">
        <span className="hello">Good morning, Marco · Wednesday 7 October</span>
        <h1 className="brief-title">3 things need your attention today</h1>
        <p className="brief-sub">Overnight, 8 agents checked 1,240 suppliers across 10 connected systems.</p>
      </div>
      <div className="attn">
        {ATTENTION.map(([t, k, h, sub, q]) => (
          <button type="button" key={h} className="attn-card" onClick={() => ask(q)}>
            <span className="row-2"><Badge tone={t}>{k}</Badge></span>
            <span className="h">{h}</span>
            <span className="sm muted">{sub}</span>
            <span className="ask">Ask elsai<ArrowRight size={14} /></span>
          </button>
        ))}
      </div>
      <div className="kpis">
        <div className="kpi"><div className="l">Suppliers monitored</div><div className="v">1,240</div></div>
        <div className="kpi"><div className="l">High risk</div><div className="v">{SUPPLIERS.filter((s) => scoreOf(s) >= 60).length}</div></div>
        <div className="kpi"><div className="l">Over concentration cap</div><div className="v">{SUPPLIERS.filter((s) => s.share > 40).length}</div></div>
        <div className="kpi"><div className="l">Money at risk · Alfa</div><div className="v">{money(alfaExp)}</div></div>
      </div>
      <div className="panel">
        <div className="panel-h"><span className="medium">Suppliers to watch</span><span className="xs muted">Click a supplier to ask about it</span></div>
        <div>
          {watch.map((s) => {
            const v = scoreOf(s), d = v - s.was
            return (
              <button type="button" key={s.id} className="watch-row" onClick={() => ask(`Tell me about ${s.name}`)}>
                <span><span className="medium">{s.name}</span><span className="xs muted" style={{ display: 'block' }}>{s.cat}</span></span>
                <span><Badge tone={lvlTone(riskLvl(v))}>{v} {riskLvl(v)}</Badge></span>
                <span className="row-2"><Spark values={trendOf(s).map((p) => p[1])} w={72} h={24} color={v >= 60 ? 'var(--bad)' : 'var(--chart-2)'} /><span className={`xs num ${d >= 10 ? 'medium' : 'muted'}`}>{d > 0 ? `▲${d}` : d < 0 ? `▼${-d}` : '—'}</span></span>
                <span className="sm">{s.risks[0] ? s.risks[0][1] : <span className="muted">None flagged</span>}</span>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
