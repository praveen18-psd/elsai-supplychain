import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { PEOPLE, SI_NODES, SI_STEPS, SI_TR, SRC_AGENTS } from '../lib/data.js'
import { actionSpec, actionsFor, answerFor, route, stepsFor } from '../lib/intents.js'
import { DEFAULT_PREFS } from '../lib/alerts.js'
import { clockT, nowT, prefersReducedMotion, wait } from '../lib/format.js'

/* Overnight agent activity shown in the Activity rail on load. */
const SEED = [
  ['08:42', 'sr', 'Prepared briefing: 3 items need a decision', null, 800],
  ['08:41', 'di', 'Traced strike to 3 deliveries · Metro Line B buffer 2 days', 'ms', 1200],
  ['08:40', 'dm', 'Detected road-haulage strike, Northern Italy, 12–14 Oct', 'news', 1500],
  ['06:05', 'ce', 'Re-read 214 contracts for new obligations', 'clm', 9600],
  ['06:02', 'sc', 'Flagged 2 suppliers over the 40% category cap', 'spend', 900],
  ['06:02', 'rs', 'Scored 1,240 suppliers · 5 changed risk band', 'credit', 6400],
  ['06:00', 'dc', 'Refreshed 10 connected systems', 'erp', 4200],
].map(([t, a, what, src, ms]) => ({ t, a, what, src, ms }))

export const ORCH0 = () => ({ status: 'idle', step: -1, ns: {}, trace: [] })

function initState() {
  return {
    view: 'brief', title: null, msgs: [], ctxSup: 'alfa', acts: {}, drafts: {},
    activity: SEED, busyAgents: {}, agentLast: {}, railTab: 'activity',
    sideOff: false, railOff: false, sideOpen: false, railOpen: false,
    orch: ORCH0(), wfFocus: null, wfQ: '',
    prefs: structuredClone(DEFAULT_PREFS), prefsDirty: false,
  }
}

const Ctx = createContext(null)

export function WorkspaceProvider({ children }) {
  const [s, setS] = useState(initState)
  const [sheet, setSheet] = useState(null)
  const [toastMsg, setToastMsg] = useState(null)
  const sRef = useRef(s)
  sRef.current = s
  const busy = useRef(false)
  const [isBusy, setBusy] = useState(false)
  const toastTimer = useRef(null)

  const mut = useCallback((fn) => setS((prev) => { const n = structuredClone(prev); fn(n); return n }), [])
  const toast = useCallback((m) => { setToastMsg(m); clearTimeout(toastTimer.current); toastTimer.current = setTimeout(() => setToastMsg(null), 2400) }, [])
  const openSheet = useCallback((title, desc, content) => setSheet({ title, desc, content }), [])
  const closeSheet = useCallback(() => setSheet(null), [])

  const setView = useCallback((view) => mut((n) => { n.view = view }), [mut])

  /* ---------- Conversation ---------- */
  const ask = useCallback(async (raw) => {
    const q = raw.trim()
    if (!q || busy.current) return
    busy.current = true; setBusy(true)
    const id = Date.now()
    const { intent, ctx } = route(q, sRef.current.ctxSup)
    const steps = stepsFor(intent, ctx)
    mut((n) => {
      if (!n.msgs.length) n.title = q.length > 60 ? q.slice(0, 57) + '…' : q
      n.view = 'chat'; n.ctxSup = ctx; n.sideOpen = false
      n.msgs.push({ id, q, intent, ctx, steps, used: [...new Set(steps.map((x) => x[0]))], cur: 0, ms: [], status: steps.length ? 'working' : 'typing', typed: 0, text: '', follow: [], collapsed: false })
    })
    const reduce = prefersReducedMotion()
    const msg = (n) => n.msgs.find((m) => m.id === id)
    for (let i = 0; i < steps.length; i++) {
      const [a, what, src] = steps[i]
      mut((n) => { n.busyAgents[a] = true; msg(n).cur = i })
      const ms = reduce ? 60 : 450 + Math.round(Math.random() * 650)
      await wait(ms)
      mut((n) => {
        n.busyAgents[a] = false; n.agentLast[a] = nowT()
        const m = msg(n); m.ms[i] = ms; m.cur = i + 1
        n.activity.unshift({ t: nowT(), a, what, src, ms, live: true })
      })
    }
    await wait(0)
    const r = answerFor(intent, ctx, sRef.current.activity)
    const text = r.text
    mut((n) => {
      const m = msg(n)
      m.status = 'typing'; m.text = r.text; m.follow = r.follow; m.collapsed = steps.length > 0
      if (intent === 'trace') { n.railTab = 'activity'; n.railOff = false; n.railOpen = true }
    })
    if (!reduce) {
      const step = Math.max(2, Math.round(text.length / 90))
      for (let i = 0; i < text.length; i += step) { mut((n) => { msg(n).typed = i }); await wait(16) }
    }
    mut((n) => { const m = msg(n); m.typed = m.text.length; m.status = 'done' })
    busy.current = false; setBusy(false)
  }, [mut])

  const newChat = useCallback(() => { if (busy.current) return; mut((n) => { n.msgs = []; n.title = null; n.view = 'brief' }) }, [mut])
  const toggleSteps = useCallback((id) => mut((n) => { const m = n.msgs.find((x) => x.id === id); m.collapsed = !m.collapsed }), [mut])

  /* ---------- Human approvals ---------- */
  const approve = useCallback((id) => {
    const spec = actionSpec(id), p = PEOPLE[spec.who]
    mut((n) => { n.acts[id] = { status: 'approved', at: nowT() }; n.activity.unshift({ t: nowT(), human: p.name, what: `Approved: ${spec.text}`, live: true }) })
    toast(spec.done || 'Approved')
  }, [mut, toast])
  const startReject = useCallback((id) => mut((n) => { n.acts[id] = { status: 'rejecting' } }), [mut])
  const cancelReject = useCallback((id) => mut((n) => { delete n.acts[id] }), [mut])
  const confirmReject = useCallback((id, reason) => {
    const spec = actionSpec(id), p = PEOPLE[spec.who]
    mut((n) => { n.acts[id] = { status: 'rejected', at: nowT(), reason }; n.activity.unshift({ t: nowT(), human: p.name, what: `Rejected: ${spec.text}`, live: true }) })
    toast('Rejection recorded')
  }, [mut, toast])

  /* ---------- Panels ---------- */
  const toggleSide = useCallback(() => mut((n) => { if (window.innerWidth <= 820) n.sideOpen = !n.sideOpen; else n.sideOff = !n.sideOff }), [mut])
  const toggleRail = useCallback(() => mut((n) => { if (window.innerWidth <= 1180) n.railOpen = !n.railOpen; else n.railOff = !n.railOff }), [mut])

  /* ---------- Agent workflow run ---------- */
  const openWorkflow = useCallback((agents, q) => { if (busy.current) return; mut((n) => { n.view = 'workflow'; n.wfFocus = agents || null; n.wfQ = q || '' }) }, [mut])
  const orchRun = useCallback(() => mut((n) => { n.orch = ORCH0(); n.orch.status = 'running'; n.wfFocus = null }), [mut])
  const orchReset = useCallback(() => mut((n) => { n.orch = ORCH0(); n.busyAgents = {} }), [mut])
  const orchHuman = useCallback((approveIt) => mut((n) => {
    const O = n.orch, id = SI_STEPS[O.step][0], who = SI_NODES[id].human, p = PEOPLE[who]
    const detail = { cp1: 'Watchlist: Cantieri Alfa', cp2: 'Bring Metro Line B batch 4 forward', cp3: 'Diversify + renegotiate gasket exclusivity' }[id]
    O.trace.push({ t: clockT(), step: SI_NODES[id].t, rule: 'Human checkpoint', src: 'Upstream results', out: approveIt ? 'Approved' : 'Held for later', human: `${p.name}, ${p.role} · ${detail}` })
    n.activity.unshift({ t: nowT(), human: p.name, what: `${approveIt ? 'Approved' : 'Held'}: ${detail}`, live: true })
    O.ns[id] = 'done'; O.status = 'running'
  }), [mut])

  useEffect(() => {
    const O = s.orch
    if (O.status !== 'running') return undefined
    const ids = SI_STEPS[O.step]
    const running = ids && ids.some((id) => O.ns[id] === 'running')
    const t = setTimeout(() => mut((n) => {
      const N = n.orch
      if (running) {
        SI_STEPS[N.step].forEach((id) => {
          const T = SI_TR[id]
          N.ns[id] = 'done'; n.busyAgents[id] = false; n.agentLast[id] = nowT()
          N.trace.push({ t: clockT(), step: SI_NODES[id].t, rule: T.rule, src: T.src, out: T.out })
          n.activity.unshift({ t: nowT(), a: id, what: T.out, src: Object.keys(SRC_AGENTS).find((k) => SRC_AGENTS[k].includes(id)) || null, ms: T.sec * 30, live: true })
        })
      }
      N.step++
      if (N.step >= SI_STEPS.length) { N.status = 'done'; return }
      const next = SI_STEPS[N.step]
      if (SI_NODES[next[0]].human) { N.ns[next[0]] = 'waiting'; N.status = 'waiting'; return }
      next.forEach((id) => { N.ns[id] = 'running'; n.busyAgents[id] = true })
    }), running ? 1100 : 300)
    return () => clearTimeout(t)
  }, [s.orch.status, s.orch.step, mut]) // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- Alert preferences ---------- */
  const setPref = useCallback((path, val) => mut((n) => {
    const keys = path.split('.'), last = keys.pop()
    const o = keys.reduce((acc, k) => acc[k], n.prefs)
    o[last] = val === undefined ? !o[last] : val
    n.prefsDirty = true
  }), [mut])
  const savePrefs = useCallback(() => {
    mut((n) => { n.prefsDirty = false; n.activity.unshift({ t: nowT(), human: 'Marco Bellini', what: 'Updated alert preferences for phone, watch and email', live: true }) })
    toast('Preferences saved · synced to phone and watch')
  }, [mut, toast])

  const value = {
    s, mut, sheet, openSheet, closeSheet, toastMsg, toast, isBusy,
    setView, ask, newChat, toggleSteps, approve, startReject, cancelReject, confirmReject,
    toggleSide, toggleRail, openWorkflow, orchRun, orchReset, orchHuman, setPref, savePrefs, actionsFor,
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export const useWS = () => useContext(Ctx)
