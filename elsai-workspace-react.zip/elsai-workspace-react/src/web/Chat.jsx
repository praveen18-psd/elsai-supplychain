import { Fragment, useEffect, useRef } from 'react'
import { ArrowRight, CheckCircle2, ChevronDown, CornerDownRight, Database, MessageSquare, UserRound, Workflow } from 'lucide-react'
import { AGENTS, PEOPLE, srcName } from '../lib/data.js'
import { actionSpec, actionsFor } from '../lib/intents.js'
import { Mark } from '../components/ui.jsx'
import { AG_ICON, AgentChip, useSourceSheet } from './common.jsx'
import AnswerBlocks from './Answers.jsx'
import { useWS } from './store.jsx'

const Arr = () => <span className="oarr"><ArrowRight size={14} /></span>

/** Source a step read from; opens the source details. */
function SourceChip({ id }) {
  const open = useSourceSheet()
  return <button type="button" className="cite" onClick={() => open(id)}><Database size={11} />{srcName(id)}</button>
}

/** You → Orchestrator → agents → Answer → person who approves; nodes light up as the run progresses. */
function OrchMap({ m }) {
  const { s } = useWS()
  const working = m.status === 'working'
  const stateOf = (a) => {
    const idx = m.steps.map((x, i) => (x[0] === a ? i : -1)).filter((i) => i >= 0)
    if (working && m.steps[m.cur]?.[0] === a) return 'run'
    if (idx.length && Math.max(...idx) < m.cur) return 'done'
    return ''
  }
  const acts = m.status === 'done' ? actionsFor(m.intent, m.ctx) : []
  const approved = acts.length && acts.every((id) => s.acts[id]?.status === 'approved')
  const owner = acts.length ? PEOPLE[actionSpec(acts[0]).who] : null
  return (
    <div className="orch" aria-label="How elsai orchestrated this answer">
      <span className="onode you"><UserRound size={12} />You</span><Arr />
      <span className={`onode ${working ? 'run' : 'done'}`}><Workflow size={12} />Orchestrator</span><Arr />
      <span className="ostack">
        {m.used.map((a) => {
          const I = AG_ICON[a]
          const srcs = [...new Set(m.steps.filter((x) => x[0] === a && x[2]).map((x) => x[2]))]
          return (
            <span className="orow" key={a}>
              <span className={`onode ${stateOf(a)}`}><I size={12} />{AGENTS[a]}</span>
              {srcs.length > 0 && (
                <>
                  <span className="olnk" aria-hidden="true" />
                  <span className="osrc"><span className="xs muted">reads</span>{srcs.map((id) => <SourceChip key={id} id={id} />)}</span>
                </>
              )}
            </span>
          )
        })}
      </span><Arr />
      <span className={`onode ${m.status === 'typing' ? 'run' : m.status === 'done' ? 'done' : ''}`}><MessageSquare size={12} />Answer</span>
      {owner && (
        <>
          <Arr />
          <span className={`onode hum ${approved ? 'done' : ''}`}>{approved ? <CheckCircle2 size={12} /> : <UserRound size={12} />}{approved ? `Approved · ${owner.name}` : `Awaiting ${owner.role}`}</span>
        </>
      )}
    </div>
  )
}

function AgentMessage({ m }) {
  const { ask, toggleSteps, openWorkflow, isBusy } = useWS()
  const working = m.status === 'working'
  const shown = working ? m.steps.slice(0, m.cur + 1) : m.steps
  const secs = (m.ms.reduce((t, x) => t + (x || 0), 0) / 1000).toFixed(1)
  return (
    <div className="msg-agent">
      <div className={`ava ${working ? 'busy' : ''}`}><Mark size={20} /></div>
      <div style={{ minWidth: 0 }}>
        <div className="who-line"><span className="me">elsai</span>{m.used.length > 0 && <><span>·</span>{m.used.map((a) => <AgentChip key={a} a={a} />)}</>}</div>
        {m.steps.length > 0 && (
          <div className={`steps ${m.collapsed ? 'collapsed' : ''}`}>
            <button type="button" className="steps-head" onClick={() => toggleSteps(m.id)}>
              {working ? <span className="spin" /> : <span className="st-ic"><CheckCircle2 size={14} style={{ color: 'var(--ok)' }} /></span>}
              <span>{working ? 'Working…' : `Worked with ${m.used.length} agent${m.used.length === 1 ? '' : 's'} · ${m.steps.length} steps · ${secs}s`}</span>
              <ChevronDown size={14} />
            </button>
            <OrchMap m={m} />
            <div>
              {shown.map(([a, what, src], i) => {
                const done = i < m.cur || !working
                return (
                  <div className="step" key={i}>
                    <span className="st-ic">{done ? <CheckCircle2 size={14} /> : <span className="spin" />}</span>
                    <span><AgentChip a={a} /> <span>{what}</span>{src && <span className="src"> · {srcName(src)}</span>}</span>
                    <span className="ms">{m.ms[i] ? (m.ms[i] / 1000).toFixed(1) + 's' : ''}</span>
                  </div>
                )
              })}
            </div>
            <div className="steps-tools"><button type="button" className="link" onClick={() => openWorkflow(m.used, m.q)}>Open in workflow</button></div>
          </div>
        )}
        {m.status !== 'working' && (
          <div className="answer">
            <div className="lead">{m.text.slice(0, m.typed)}{m.status === 'typing' && <span className="caret" />}</div>
            {m.status === 'done' && (
              <>
                <div className="blocks"><AnswerBlocks intent={m.intent} ctx={m.ctx} /></div>
                {m.follow.length > 0 && (
                  <div className="followups">
                    {m.follow.map((f) => <button type="button" key={f} className="fu" disabled={isBusy} onClick={() => ask(f)}><CornerDownRight size={13} />{f}</button>)}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default function Chat({ scrollRef }) {
  const { s } = useWS()
  const last = s.msgs[s.msgs.length - 1]
  const sig = last ? `${last.id}-${last.cur}-${last.status}-${Math.floor(last.typed / 40)}` : ''
  const first = useRef(true)
  useEffect(() => {
    const el = scrollRef.current
    if (el && !first.current) el.scrollTop = el.scrollHeight
    first.current = false
  }, [sig, scrollRef])
  return (
    <div className="col g6">
      {s.msgs.map((m) => (
        <Fragment key={m.id}>
          <div className="msg-user">{m.q}</div>
          <AgentMessage m={m} />
        </Fragment>
      ))}
    </div>
  )
}
