import { CheckCircle2, Mail, Send, Smartphone, Watch } from 'lucide-react'
import { SUPPLIERS, scoreOf } from '../lib/data.js'
import { EVENTS, deliver } from '../lib/alerts.js'
import { riskLvl } from '../lib/format.js'
import { Switch } from '../components/ui.jsx'
import { useWS } from './store.jsx'

function Row({ label, desc, children, style }) {
  return (
    <div className="prow" style={style}>
      <div><div className="pl">{label}</div>{desc && <div className="pd">{desc}</div>}</div>
      <div>{children}</div>
    </div>
  )
}

function Device({ icon: I, title, desc }) {
  return <span className="dev"><span className="di"><I size={16} /></span><span><span className="pl">{title}</span><span className="pd" style={{ display: 'block' }}>{desc}</span></span></span>
}

function Preview({ P }) {
  const mark = (v) => (v ? <td className="yes c"><CheckCircle2 size={16} /></td> : <td className="no c">—</td>)
  const n = (k) => EVENTS.filter((e) => deliver(e, P)[k]).length
  return (
    <div className="panel">
      <div className="panel-h"><span className="medium">What you'd receive</span><span className="xs muted">Today's events, with these settings</span></div>
      <div className="x-scroll">
        <table className="mini-tbl pv">
          <thead><tr><th>Alert</th><th className="c">Phone</th><th className="c">Watch</th><th className="c">Digest</th></tr></thead>
          <tbody>
            {EVENTS.map((ev) => {
              const d = deliver(ev, P)
              return <tr key={ev.title}><td><span className="medium">{ev.title}</span><span className="xs muted" style={{ display: 'block' }}>{ev.sub}</span></td>{mark(d.phone)}{mark(d.watch)}{mark(d.email)}</tr>
            })}
          </tbody>
        </table>
      </div>
      <div className="panel-b sm muted" style={{ borderTop: '1px solid var(--border)' }}>
        {n('phone')} to phone · {n('watch')} to watch · {n('email')} in the {P.dig.time} digest{P.quiet.on ? ` · silent ${P.quiet.from}–${P.quiet.to}${P.quiet.crit ? ' except High' : ''}` : ''}
      </div>
    </div>
  )
}

export default function Prefs() {
  const { s, setPref, savePrefs, toast } = useWS()
  const P = s.prefs
  const T = (path, label) => {
    const val = path.split('.').reduce((o, k) => o[k], P)
    return <Switch on={val} label={label} onChange={() => setPref(path)} />
  }
  const sendTest = () => {
    const where = [P.ch.mobile && 'phone', P.ch.watch && 'watch'].filter(Boolean)
    toast(where.length ? `Test alert sent to ${where.join(' and ')}` : 'Phone and watch alerts are off')
  }

  return (
    <div className="col g4">
      <div className="wf-head">
        <div className="col g1"><h1 style={{ fontSize: 22 }}>Alerts &amp; devices</h1><span className="sm muted">Choose what reaches your phone, watch and inbox when you're away from your desk</span></div>
        <div className="row-2">
          <button type="button" className="btn btn-outline btn-sm" onClick={sendTest}><Send size={16} />Send test alert</button>
          <button type="button" className="btn btn-default btn-sm" disabled={!s.prefsDirty} onClick={savePrefs}>{s.prefsDirty ? 'Save preferences' : 'Saved'}</button>
        </div>
      </div>
      <div className="prefs-grid">
        <div className="col g4">
          <div className="panel">
            <div className="panel-h"><span className="medium">Devices</span><span className="xs muted">Where alerts are delivered</span></div>
            <div className="panel-b">
              <Row label={<Device icon={Smartphone} title="Mobile app" desc="Marco's phone · push notifications" />}>{T('ch.mobile', 'Mobile push')}</Row>
              <Row label={<Device icon={Watch} title="Watch" desc="Paired with Marco's phone" />}>{T('ch.watch', 'Watch alerts')}</Row>
              <Row label={<Device icon={Mail} title="Email digest" desc="One summary a day" />}>
                <span className="row-2"><input className="time" type="time" value={P.dig.time} aria-label="Digest time" onChange={(e) => setPref('dig.time', e.target.value)} />{T('ch.email', 'Email digest')}</span>
              </Row>
            </div>
          </div>

          <div className={`panel pgroup ${P.risk.on ? '' : 'off'}`}>
            <div className="panel-h"><span className="medium">Supplier risk</span>{T('risk.on', 'Supplier risk alerts')}</div>
            <div className="panel-b">
              <Row label="Risk score reaches" desc="Alert when a supplier crosses this score">
                <span className="rng"><input type="range" min="35" max="90" step="5" value={P.risk.threshold} aria-label="Risk threshold" onChange={(e) => setPref('risk.threshold', +e.target.value)} /><span className="val">{P.risk.threshold}</span></span>
              </Row>
              <Row label="Or rises quickly" desc="Points gained in 30 days">
                <span className="rng"><input type="range" min="5" max="30" step="1" value={P.risk.jump} aria-label="Risk rise" onChange={(e) => setPref('risk.jump', +e.target.value)} /><span className="val">+{P.risk.jump}</span></span>
              </Row>
              <Row label="Sanctions or adverse media hit" desc="Any match on screening lists">{T('risk.sanc', 'Sanctions alerts')}</Row>
              <Row label="Concentration over cap" desc="Supplier exceeds 40% of category spend">{T('risk.conc', 'Concentration alerts')}</Row>
              <div className="prow" style={{ gridTemplateColumns: '1fr' }}>
                <div>
                  <div className="row between">
                    <span className="pl">Suppliers</span>
                    <div className="tabs-list" role="group" aria-label="Supplier scope">
                      <button type="button" aria-pressed={P.risk.scope === 'all'} onClick={() => setPref('risk.scope', 'all')}>All key suppliers</button>
                      <button type="button" aria-pressed={P.risk.scope === 'sel'} onClick={() => setPref('risk.scope', 'sel')}>Selected</button>
                    </div>
                  </div>
                  {P.risk.scope === 'sel' ? (
                    <div className="suplist">
                      {SUPPLIERS.map((x) => {
                        const v = scoreOf(x)
                        return <div className="supitem" key={x.id}><span><span className="medium">{x.name}</span> <span className="xs muted">{v} {riskLvl(v)}</span></span>{T(`risk.sup.${x.id}`, x.name)}</div>
                      })}
                    </div>
                  ) : <div className="pd">All 8 key suppliers on Rail Tunnel Lot 4</div>}
                </div>
              </div>
            </div>
          </div>

          <div className={`panel pgroup ${P.dis.on ? '' : 'off'}`}>
            <div className="panel-h"><span className="medium">Disruptions</span>{T('dis.on', 'Disruption alerts')}</div>
            <div className="panel-b">
              <Row label="Minimum severity" desc="Strikes, closures, weather and supplier incidents">
                <select className="select sm" value={P.dis.min} aria-label="Minimum severity" onChange={(e) => setPref('dis.min', e.target.value)}>{['High', 'Medium', 'Low'].map((x) => <option key={x}>{x}</option>)}</select>
              </Row>
            </div>
          </div>

          <div className={`panel pgroup ${P.ten.on ? '' : 'off'}`}>
            <div className="panel-h"><span className="medium">Tender updates</span>{T('ten.on', 'Tender alerts')}</div>
            <div className="panel-b">
              <Row label="Bids received" desc="When a tender closes">{T('ten.bids', 'Bids received')}</Row>
              <Row label="Evaluation complete" desc="Price and risk-weighted ranking ready">{T('ten.eval', 'Evaluation complete')}</Row>
              <Row label="Clarification replies" desc="A bidder answers a clarification">{T('ten.clar', 'Clarification replies')}</Row>
              <Row label="Award decisions" desc="Committee records a decision">{T('ten.award', 'Award decisions')}</Row>
            </div>
          </div>

          <div className="panel">
            <div className="panel-h"><span className="medium">Approvals and timing</span></div>
            <div className="panel-b">
              <Row label="Approvals waiting for me" desc="Actions that need your sign-off">{T('appr.on', 'Approval alerts')}</Row>
              <Row label="On the watch" desc="Keep the watch for what matters most">
                <select className="select sm" value={P.watch.rule} aria-label="Watch alerts" onChange={(e) => setPref('watch.rule', e.target.value)}>
                  <option value="high">High severity and approvals</option>
                  <option value="approvals">Approvals only</option>
                  <option value="all">Everything sent to phone</option>
                </select>
              </Row>
              <Row label="Quiet hours" desc={P.quiet.on ? `Silent ${P.quiet.from}–${P.quiet.to}` : 'Off'}>
                <span className="row-2">
                  <input className="time" type="time" value={P.quiet.from} aria-label="Quiet from" onChange={(e) => setPref('quiet.from', e.target.value)} />
                  <span className="xs muted">to</span>
                  <input className="time" type="time" value={P.quiet.to} aria-label="Quiet to" onChange={(e) => setPref('quiet.to', e.target.value)} />
                  {T('quiet.on', 'Quiet hours')}
                </span>
              </Row>
              <Row label="Let High severity through" desc="During quiet hours">{T('quiet.crit', 'High severity during quiet hours')}</Row>
            </div>
          </div>
        </div>
        <div className="prefs-side"><Preview P={P} /></div>
      </div>
    </div>
  )
}
