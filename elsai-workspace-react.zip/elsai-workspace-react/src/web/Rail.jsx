import { UserRound, X } from 'lucide-react'
import { AGENTS, SOURCES, agentSources } from '../lib/data.js'
import { AG_ICON, AgentChip, Cite, useSourceSheet } from './common.jsx'
import { useWS } from './store.jsx'

/** Right-hand rail: live agent activity, agent status and connected sources. */
export default function Rail() {
  const { s, mut, toggleRail } = useWS()
  const openSrc = useSourceSheet()
  const tab = s.railTab
  const setTab = (t) => mut((n) => { n.railTab = t })
  return (
    <aside className={`crail ${s.railOpen ? 'open' : ''}`} aria-label="Agent activity">
      <div className="rail-head">
        <div className="rail-tabs" role="group" aria-label="Rail view">
          {[['activity', 'Activity'], ['agents', 'Agents'], ['sources', 'Sources']].map(([k, l]) => <button type="button" key={k} aria-pressed={tab === k} onClick={() => setTab(k)}>{l}</button>)}
        </div>
        <button type="button" className="btn btn-ghost btn-icon btn-sm rail-toggle" aria-label="Close activity" onClick={toggleRail}><X size={16} /></button>
      </div>
      <div className="rail-body">
        {tab === 'activity' && (
          <>
            <div className="xs muted" style={{ padding: '4px 0 8px' }}>Every agent call, newest first</div>
            {s.activity.map((e, i) => (
              <div key={`${e.t}-${i}-${e.what}`} className={`ev ${e.live ? 'live' : ''} ${e.human ? 'human' : ''}`}>
                <span className="tm">{e.t}</span>
                <div>
                  <div className="what">{e.what}</div>
                  <div className="meta">
                    {e.human ? <span className="achip"><UserRound size={12} />{e.human}</span> : <AgentChip a={e.a} />}
                    {e.src && <Cite id={e.src} />}
                    {e.ms ? <span>{(e.ms / 1000).toFixed(1)}s</span> : null}
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
        {tab === 'agents' && (
          <>
            <div className="xs muted" style={{ padding: '4px 0 8px' }}>Read-only access to your systems · no binding actions</div>
            {Object.keys(AGENTS).map((a) => {
              const busy = s.busyAgents[a], I = AG_ICON[a], reads = agentSources(a).length
              return (
                <div className="agent-row" key={a}>
                  <span className={`adot ${busy ? 'busy' : ''}`} />
                  <div><div className="medium row-2"><I size={14} />{AGENTS[a]}</div><div className="xs muted">{reads} source{reads === 1 ? '' : 's'} · last run {s.agentLast[a] || '06:02'}</div></div>
                  <span className={`xs ${busy ? '' : 'muted'}`} style={busy ? { color: 'var(--brand)', fontWeight: 500 } : undefined}>{busy ? 'Working' : 'Ready'}</span>
                </div>
              )
            })}
          </>
        )}
        {tab === 'sources' && (
          <>
            <div className="xs muted" style={{ padding: '4px 0 8px' }}>Connected systems · read-only</div>
            {SOURCES.map((x) => (
              <div className="agent-row" key={x.id} style={{ gridTemplateColumns: '10px minmax(0,1fr)' }}>
                <span className="adot" />
                <button type="button" className="link" style={{ textAlign: 'left', whiteSpace: 'normal', fontSize: 13, textDecoration: 'none', color: 'var(--foreground)' }} onClick={() => openSrc(x.id)}>
                  <span className="medium">{x.name}</span><span className="xs muted" style={{ display: 'block' }}>{x.kind} · updated {x.last}</span>
                </button>
              </div>
            ))}
          </>
        )}
      </div>
    </aside>
  )
}
