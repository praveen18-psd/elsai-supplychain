import { useEffect, useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { ALTS, B, DIMS, DIM_KEYS, EXPOSURE, NAIVE_ORDER, RW_ORDER, SOURCES, SUPPLIERS, scoreOf, sup, trendOf } from '../lib/data.js'
import { draftBody } from '../lib/intents.js'
import { eur, lvlTone, money, prefersReducedMotion, riskLvl } from '../lib/format.js'
import { Badge, Spark, TrendChart } from '../components/ui.jsx'
import { ActionCard, AgentChip, Cite, Cites, useSourceSheet } from './common.jsx'
import { useWS } from './store.jsx'

const Move = ({ d }) => (d > 0 ? <Badge tone="ok">▲ {d}</Badge> : d < 0 ? <Badge tone="bad">▼ {-d}</Badge> : <Badge>—</Badge>)

function Movers() {
  const { ask } = useWS()
  const list = [...SUPPLIERS].sort((a, b) => (scoreOf(b) - b.was) - (scoreOf(a) - a.was)).slice(0, 5)
  return (
    <>
      <div className="panel">
        <table className="mini-tbl">
          <thead><tr><th>Supplier</th><th>Risk</th><th>Trend</th><th>Since Jul</th><th>Main driver</th></tr></thead>
          <tbody>
            {list.map((s) => {
              const v = scoreOf(s)
              return (
                <tr key={s.id} className="click" onClick={() => ask(`Tell me about ${s.name}`)}>
                  <td><span className="medium">{s.name}</span><span className="xs muted" style={{ display: 'block' }}>{s.cat}</span></td>
                  <td><Badge tone={lvlTone(riskLvl(v))}>{v} {riskLvl(v)}</Badge></td>
                  <td><Spark values={trendOf(s).map((p) => p[1])} w={72} h={24} color={v >= 60 ? 'var(--bad)' : 'var(--chart-2)'} /></td>
                  <td className="num medium">▲ {v - s.was}</td>
                  <td className="sm">{s.risks[0] ? s.risks[0][1] : '—'}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <Cites ids={['credit', 'ms', 'spend', 'comp']} />
    </>
  )
}

function SupplierCard({ ctx }) {
  const s = sup(ctx), v = scoreOf(s), lv = riskLvl(v), isAlfa = s.id === 'alfa'
  const exp = EXPOSURE.filter((e) => e.sub === s.name).reduce((t, e) => t + e.amt, 0)
  return (
    <>
      <div className="panel">
        <div className="panel-h">
          <div className="col g1"><span className="medium">{s.name}</span><span className="xs muted">{s.cat} · {s.country} · {s.projects} projects · {s.share}% of category spend</span></div>
          <Badge tone={lvlTone(lv)}>{v} {lv}</Badge>
        </div>
        <div className="panel-b duo">
          <div><TrendChart data={trendOf(s)} /></div>
          <div className="col g3">
            <div className="dimgrid">
              {DIM_KEYS.map(([k, n]) => {
                const x = s.dims[k], l = riskLvl(x), det = isAlfa ? (DIMS.find((d) => d.n === n) || {}).d : ''
                return (
                  <div className="dim2" key={k} title={det}>
                    <span>{n}</span><span className="track"><span className={`f-${lvlTone(l)}`} style={{ width: `${x}%` }} /></span><span><Badge tone={lvlTone(l)}>{x} {l}</Badge></span>
                  </div>
                )
              })}
            </div>
            {s.risks.length > 0 && <div className="row-2">{s.risks.map(([t, l]) => <Badge key={l} tone={t}>{l}</Badge>)}</div>}
            {exp > 0 && <div className="sm"><span className="muted">Money at risk:</span> <span className="medium">{money(exp)}</span></div>}
          </div>
        </div>
      </div>
      {lv !== 'Low' && <ActionCard id={`watch-${s.id}`} />}
      <Cites ids={['credit', 'sanc', 'comp', 'esg', 'ms', 'spend']} />
    </>
  )
}

function Disruption() {
  const N = ({ sev, title, sub, tone }) => (
    <div className={`n sev-${sev}`}><div className="row between"><span className="medium">{title}</span><Badge tone={tone}>{sev}</Badge></div><span className="xs muted">{sub}</span></div>
  )
  return (
    <>
      <div className="panel panel-b">
        <div className="flow3">
          <div className="n"><span className="xs muted">Event</span><div className="medium">Haulage strike</div><span className="xs muted">12–14 Oct · 72 h</span></div>
          <div className="arr"><ArrowRight size={14} /></div>
          <div className="col">
            <div className="n"><span className="medium">Cantieri Alfa</span> · Cremona</div>
            <div className="n"><span className="medium">Delta Costruzioni</span> · Brescia</div>
            <div className="n"><span className="medium">Iota Heavy Haulage</span> · Piacenza</div>
          </div>
          <div className="arr"><ArrowRight size={14} /></div>
          <div className="col">
            <N sev="High" tone="bad" title="Metro Line B · batch 4" sub="Due 14 Oct · 2-day buffer" />
            <N sev="Medium" tone="warn" title="Lot 4 · gasket shipment" sub="Due 15 Oct · 9-day buffer" />
            <N sev="Low" tone="ok" title="Ring Road · beams" sub="21-day float" />
          </div>
        </div>
      </div>
      <ActionCard id="strike" />
      <Cites ids={['news', 'ms', 'erp']} />
    </>
  )
}

function Exposure({ ctx }) {
  const s = sup(ctx), items = EXPOSURE.filter((e) => e.sub === s.name).sort((a, b) => b.amt - a.amt)
  if (!items.length) return <Cites ids={['clm', 'spend', 'ms']} />
  const tot = items.reduce((t, e) => t + e.amt, 0)
  return (
    <>
      <div className="panel">
        <div className="panel-h"><span className="medium">Exposure · {s.name}</span><span className="medium num" style={{ fontSize: 18 }}>{money(tot)}</span></div>
        <table className="mini-tbl"><tbody>
          {items.map((e, i) => (
            <tr key={i}><td className="medium">{e.type}</td><td><span>{e.project}</span><span className="xs muted" style={{ display: 'block' }}>{e.ref}</span></td><td className="num medium" style={{ textAlign: 'right' }}>{money(e.amt)}</td></tr>
          ))}
        </tbody></table>
      </div>
      {s.id === 'alfa' && <ActionCard id="exp-alfa" />}
      <Cites ids={['clm', 'spend', 'ms']} />
    </>
  )
}

function Alternates({ ctx }) {
  if (!/precast/i.test(sup(ctx).cat)) return <Cites ids={['erp', 'cert']} />
  return (
    <>
      <div className="panel">
        <table className="mini-tbl">
          <thead><tr><th>#</th><th>Supplier</th><th>Why</th><th>Risk</th><th>Score</th></tr></thead>
          <tbody>
            {ALTS.map((a) => (
              <tr key={a.id}>
                <td className="num medium">{a.rank}</td>
                <td><span className="medium">{a.name}</span><span className="xs muted" style={{ display: 'block' }}>{a.loc}</span></td>
                <td className="sm">{a.reason}</td>
                <td><Badge tone={lvlTone(riskLvl(a.risk))}>Risk {a.risk}</Badge></td>
                <td className="num medium">{a.score}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ActionCard id="alts" />
      <Cites ids={['erp', 'cert', 'credit', 'spend']} />
    </>
  )
}

const RK_H = 58

/** Starts on the price ranking, then elsai re-ranks: rows slide into the risk-weighted order. */
function RankReveal() {
  const [mode, setMode] = useState('price')
  useEffect(() => {
    const t = setTimeout(() => setMode('risk'), prefersReducedMotion() ? 0 : 1400)
    return () => clearTimeout(t)
  }, [])
  const risk = mode === 'risk'
  return (
    <div className={`rk ${risk ? 'mode-risk' : ''}`}>
      <div className="rk-top">
        <div className="col g1">
          <span className="medium">TND-2026-014 · Precast tunnel lining segments</span>
          <span className="xs muted">{risk ? "elsai's view: effective cost, compliance, supplier risk and delivery record" : 'What most committees see: lowest compliant price first'}</span>
        </div>
        <div className="tabs-list" role="group" aria-label="Ranking view">
          <button type="button" aria-pressed={!risk} onClick={() => setMode('price')}>Price ranking</button>
          <button type="button" aria-pressed={risk} onClick={() => setMode('risk')}>Risk-weighted</button>
        </div>
      </div>
      <div className="x-scroll">
        <div className="rk-tbl">
          <div className="rk-head"><span>#</span><span>Bidder</span><span>Quoted</span><span>Compliance</span><span className="rcol">Effective</span><span className="rcol">Supplier risk</span><span className="rcol" style={{ textAlign: 'right' }}>Score</span></div>
          <div className="rk-rows" style={{ height: NAIVE_ORDER.length * RK_H }}>
            {NAIVE_ORDER.map((id) => {
              const b = B[id], cls = b.naive < b.rw ? 'dn' : b.naive > b.rw ? 'up' : ''
              return (
                <div key={id} className={`rk-row ${cls}`} style={{ top: ((risk ? b.rw : b.naive) - 1) * RK_H }}>
                  <span className="rk-n">{risk ? b.rw : b.naive}</span>
                  <span className="bn"><span className="row-2" style={{ flexWrap: 'nowrap' }}><span className="medium">{b.name}</span><span className="mv"><Move d={b.naive - b.rw} /></span></span><span className="xs muted">{b.terms}</span></span>
                  <span className="num">{eur(b.quoted)}</span>
                  <span><Badge tone={b.comp.tone}>{b.comp.label}</Badge></span>
                  <span className="num rcol">{b.eff ? eur(b.eff) : <span className="xs muted">Held</span>}</span>
                  <span className="rcol"><Badge tone={lvlTone(b.lvl)}>{b.risk} {b.lvl}</Badge></span>
                  <span className="num semi rcol" style={{ textAlign: 'right' }}>{b.score ?? '—'}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>
      <div className="rk-foot xs muted">{risk ? 'Re-ranked by elsai · Cantieri Alfa drops from 1st to 3rd, Gamma Precast rises to 1st' : 'Price only · supplier risk, payment terms and delivery record not considered'}</div>
    </div>
  )
}

const FACTORS = [
  ['40%', 'Effective cost', 'Quoted price adjusted for advances, payment days and discounts', 'be', 'clm'],
  ['30%', 'Technical compliance', '10 requirements from Spec TS-04, incl. fire resistance', 'be', 'clm'],
  ['20%', 'Supplier risk', 'Credit, sanctions, ESG and site safety', 'rs', 'credit'],
  ['10%', 'Delivery record', 'Milestones on our live contracts', 'di', 'ms'],
]

function Weighed() {
  const { ask } = useWS()
  return (
    <div className="panel">
      <div className="panel-h"><span className="medium">What elsai weighed</span><button type="button" className="link" onClick={() => ask('Show me the agent trace')}>See the trace</button></div>
      <div className="weigh">
        {FACTORS.map(([w, t, d, a, s]) => (
          <div className="wf" key={t}><div className="wv-pct">{w}</div><div className="medium sm">{t}</div><div className="xs muted">{d}</div><div className="row-2" style={{ marginTop: 6 }}><AgentChip a={a} /><Cite id={s} /></div></div>
        ))}
      </div>
    </div>
  )
}

function WhyMoved() {
  return (
    <div className="panel">
      <div className="panel-h"><span className="medium">Why the order changed</span><span className="xs muted">Signals found by the agents, with evidence</span></div>
      <div>
        {RW_ORDER.map((id) => {
          const b = B[id]
          return (
            <div className="why-r" key={id}>
              <div className="row-2" style={{ flexWrap: 'nowrap', alignItems: 'flex-start', gap: 10 }}>
                <span style={{ flex: 'none' }}><Move d={b.naive - b.rw} /></span>
                <div className="col g2" style={{ minWidth: 0, flex: 1 }}>
                  <span className="medium">{b.name} <span className="xs muted">· price rank {b.naive} → risk-weighted {b.rw}</span></span>
                  <div className="sigs">
                    {b.why.flags.map((f) => (
                      <div className="sig" key={f.label}><Badge tone={f.tone}>{f.tag}</Badge><span className="sm">{f.label}</span><span className="xs muted">{f.agent} · {f.src}</span></div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function Bids() {
  return (
    <>
      <RankReveal />
      <Weighed />
      <WhyMoved />
      <ActionCard id="award" />
      <Cites ids={['clm', 'credit', 'ms', 'spend']} />
    </>
  )
}

function Draft({ ctx }) {
  const s = sup(ctx)
  return (
    <>
      <div className="panel">
        <div className="panel-h"><span className="sm"><span className="muted">To:</span> {s.name} · supplier portal</span><Badge>Draft</Badge></div>
        <div className="panel-b letter" style={{ border: 0, borderRadius: 0 }}>{draftBody(s)}</div>
      </div>
      <ActionCard id={`draft-${s.id}`} />
      <Cites ids={['clm', 'ms']} />
    </>
  )
}

function Trace() {
  const { s } = useWS()
  const live = s.activity.filter((e) => e.live).slice(0, 12)
  return (
    <div className="panel">
      <table className="mini-tbl">
        <thead><tr><th>Time</th><th>Agent</th><th>Step</th><th>Source</th></tr></thead>
        <tbody>
          {live.length === 0 && <tr><td colSpan={4} className="muted sm">No calls yet</td></tr>}
          {live.map((e, i) => (
            <tr key={i}>
              <td className="num xs muted">{e.t}</td>
              <td>{e.human ? <Badge tone="human">{e.human}</Badge> : <AgentChip a={e.a} />}</td>
              <td className="sm">{e.what}</td>
              <td>{e.src ? <Cite id={e.src} /> : <span className="xs muted">—</span>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function Sources() {
  const open = useSourceSheet()
  return (
    <div className="panel">
      <table className="mini-tbl">
        <thead><tr><th>Source</th><th>Type</th><th>Updated</th></tr></thead>
        <tbody>
          {SOURCES.map((x) => (
            <tr key={x.id} className="click" onClick={() => open(x.id)}>
              <td className="medium">{x.name}</td><td><Badge tone={x.kind === 'Internal' ? 'secondary' : 'neutral'}>{x.kind}</Badge></td><td className="sm num">{x.last}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/** Rich blocks under an answer, by intent. */
export default function AnswerBlocks({ intent, ctx }) {
  switch (intent) {
    case 'movers': return <Movers />
    case 'supplier': return <SupplierCard ctx={ctx} />
    case 'disruption': return <Disruption />
    case 'exposure': return <Exposure ctx={ctx} />
    case 'alternates': return <Alternates ctx={ctx} />
    case 'bids': return <Bids />
    case 'draft': return <Draft ctx={ctx} />
    case 'trace': return <Trace />
    case 'sources': return <Sources />
    default: return null
  }
}
