import { useState } from 'react'
import { AlertCircle, Check, CheckCircle2, ClipboardCheck, Database, FileText, Gauge, Lightbulb, Link2, PieChart, Radar, Repeat, Scale, Truck } from 'lucide-react'
import { AGENTS, PEOPLE, SI_NODES, SI_TR, SOURCES, agentSources, srcName } from '../lib/data.js'
import { actionSpec } from '../lib/intents.js'
import { Badge, Owner } from '../components/ui.jsx'
import { useWS } from './store.jsx'

export const AG_ICON = { dc: Database, rs: Gauge, sc: PieChart, dm: Radar, di: Truck, ce: FileText, as: Repeat, sr: Lightbulb, be: Scale }

export function AgentChip({ a }) {
  const I = AG_ICON[a]
  return <span className="achip">{I && <I size={12} />}{AGENTS[a]}</span>
}

export function useSourceSheet() {
  const { openSheet } = useWS()
  return (id) => {
    const x = SOURCES.find((s) => s.id === id)
    const agents = Object.keys(AGENTS).filter((a) => agentSources(a).includes(id))
    openSheet(x.name, x.kind, (
      <>
        <div className="row-2"><Badge tone="ok">Connected</Badge><Badge tone={x.kind === 'Internal' ? 'secondary' : 'neutral'}>{x.kind}</Badge></div>
        <div className="col g2"><span className="xs muted medium">Provides</span><p>{x.provides}</p></div>
        <dl className="kv">
          <dt>Agents</dt><dd><div className="row-2">{agents.map((a) => <AgentChip key={a} a={a} />)}</div></dd>
          <dt>Fields used</dt><dd>{x.fields}</dd>
          <dt>Refresh</dt><dd>{x.refresh}</dd>
          <dt>Last updated</dt><dd>{x.last}</dd>
          <dt>Volume</dt><dd>{x.records}</dd>
          <dt>Data owner</dt><dd>{x.owner}</dd>
          <dt>Access</dt><dd>Read-only</dd>
        </dl>
      </>
    ))
  }
}

export function Cite({ id }) {
  const open = useSourceSheet()
  return <button type="button" className="cite" onClick={() => open(id)}><Link2 size={11} />{srcName(id)}</button>
}

export function Cites({ ids }) {
  return <div className="cites"><span>Sources</span>{ids.map((id) => <Cite key={id} id={id} />)}</div>
}

export function useNodeSheet() {
  const { openSheet } = useWS()
  return (id) => {
    const n = SI_NODES[id]
    if (n.human) {
      openSheet(n.t, 'Human checkpoint', (
        <dl className="kv"><dt>Decision owner</dt><dd><Owner who={n.human} /></dd><dt>Input</dt><dd>Results of the agents before it</dd><dt>Actions</dt><dd>Approve · hold with reason</dd></dl>
      ))
      return
    }
    const T = SI_TR[id]
    openSheet(n.t, 'Agent', (
      <>
        <div className="row-2"><AgentChip a={id} /><Badge tone="ok">Ready</Badge></div>
        <dl className="kv">
          <dt>Data sources</dt><dd><div className="row-2">{agentSources(id).map((sid) => <Cite key={sid} id={sid} />)}</div></dd>
          <dt>Rule</dt><dd>{T.rule}</dd>
          <dt>Model</dt><dd>{T.model}</dd>
          <dt>Last output</dt><dd>{T.out}</dd>
          <dt>Binding actions</dt><dd>None · proposes only</dd>
        </dl>
      </>
    ))
  }
}

/** A proposed action from an agent; the named person approves or rejects it (with a reason). */
export function ActionCard({ id }) {
  const { s, approve, startReject, cancelReject, confirmReject } = useWS()
  const [reason, setReason] = useState('')
  const o = actionSpec(id), p = PEOPLE[o.who], st = s.acts[id]
  return (
    <div className="act-card">
      <div className="row between"><span className="row-2 xs muted"><ClipboardCheck size={14} />Proposed action</span><Badge tone="human">Needs {p.role}</Badge></div>
      <div className="t">{o.text}</div>
      {o.note && <div className="sm muted">{o.note}</div>}
      {st?.status === 'approved' && (
        <div className="alert-box ok"><CheckCircle2 size={16} /><div className="col g1"><span className="medium">{o.done || 'Approved'} · {st.at}</span><span className="xs muted">{p.name}, {p.role}</span></div></div>
      )}
      {st?.status === 'rejected' && (
        <div className="alert-box warn"><AlertCircle size={16} /><div className="col g1"><span className="medium">Rejected · {st.at}</span><span className="xs muted">{p.name} · {st.reason}</span></div></div>
      )}
      {st?.status === 'rejecting' && (
        <>
          <div className="field"><label className="label" htmlFor={`rj-${id}`}>Reason</label><textarea className="textarea" id={`rj-${id}`} placeholder="Required" value={reason} onChange={(e) => setReason(e.target.value)} /></div>
          <div className="row-2">
            <button type="button" className="btn btn-default btn-sm" disabled={reason.trim().length < 10} onClick={() => confirmReject(id, reason.trim())}>Reject</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => cancelReject(id)}>Cancel</button>
          </div>
        </>
      )}
      {!st && (
        <div className="row-2">
          <button type="button" className="btn btn-default btn-sm" onClick={() => approve(id)}><Check size={16} />Approve</button>
          <button type="button" className="btn btn-outline btn-sm" onClick={() => startReject(id)}>Reject</button>
          <span style={{ marginLeft: 'auto' }}><Owner who={o.who} /></span>
        </div>
      )}
    </div>
  )
}
