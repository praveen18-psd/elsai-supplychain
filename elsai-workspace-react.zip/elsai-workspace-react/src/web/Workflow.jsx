import { useEffect, useRef, useState } from 'react'
import { Check, Loader2, Play, RotateCcw, Workflow as WorkflowIcon } from 'lucide-react'
import { PEOPLE, SI_EDGES, SI_NODES, SI_STEPS } from '../lib/data.js'
import { Badge } from '../components/ui.jsx'
import { useNodeSheet } from './common.jsx'
import { useWS } from './store.jsx'

const NW = 168, NH = 72, CW = 1280, CH = 372

function edgePath(a, b, mode) {
  const A = SI_NODES[a], Bn = SI_NODES[b]
  if (mode === 'h') {
    const right = Bn.x > A.x
    const x1 = right ? A.x + NW : A.x, y1 = A.y + NH / 2, x2 = right ? Bn.x : Bn.x + NW, y2 = Bn.y + NH / 2, mx = (x1 + x2) / 2
    return `M${x1} ${y1} C${mx} ${y1},${mx} ${y2},${x2 - (right ? 6 : -6)} ${y2}`
  }
  const down = Bn.y > A.y
  const x1 = A.x + NW / 2, y1 = down ? A.y + NH : A.y, x2 = Bn.x + NW / 2, y2 = down ? Bn.y : Bn.y + NH, my = (y1 + y2) / 2
  return `M${x1} ${y1} C${x1} ${my},${x2} ${my},${x2} ${y2 + (down ? -6 : 6)}`
}

function useFitScale(ref) {
  const [scale, setScale] = useState(1)
  useEffect(() => {
    const el = ref.current
    if (!el) return undefined
    const update = () => setScale(Math.min(1, el.clientWidth / CW))
    update()
    const ro = new ResizeObserver(update)
    ro.observe(el)
    return () => ro.disconnect()
  }, [ref])
  return scale
}

export default function WorkflowView() {
  const { s, mut, orchRun, orchReset, orchHuman } = useWS()
  const openNode = useNodeSheet()
  const wrap = useRef(null)
  const scale = useFitScale(wrap)
  const O = s.orch, F = s.wfFocus
  const inF = (id) => F && (F.includes(id) || id === 'dc')

  let controls
  if (O.status === 'waiting') {
    const st = SI_STEPS[O.step][0], who = SI_NODES[st].human
    controls = (
      <div className="waitbox">
        <Badge tone="human">Paused</Badge>
        <div className="col g1" style={{ flex: 1, minWidth: 220 }}><span className="medium">{SI_NODES[st].t}</span><span className="xs muted">Awaiting {SI_NODES[st].s}</span></div>
        <button type="button" className="btn btn-default" onClick={() => orchHuman(true)}><Check size={16} />Approve · {PEOPLE[who].name}</button>
        <button type="button" className="btn btn-outline" onClick={() => orchHuman(false)}>Hold for later</button>
      </div>
    )
  } else {
    controls = (
      <div className="row between">
        <div className="row-2">
          <button type="button" className="btn btn-default" disabled={O.status === 'running'} onClick={orchRun}>
            {O.status === 'running' ? <Loader2 size={16} /> : <Play size={16} />}{O.status === 'idle' ? 'Run now' : O.status === 'done' ? 'Run again' : 'Running'}
          </button>
          {O.status !== 'idle' && <button type="button" className="btn btn-ghost" onClick={orchReset}><RotateCcw size={16} />Reset</button>}
          {O.status === 'done' && <Badge tone="ok">Run complete</Badge>}
        </div>
        <div className="row-2"><Badge>Agent</Badge><Badge tone="human">Human checkpoint</Badge></div>
      </div>
    )
  }

  return (
    <div className="col g4">
      <div className="wf-head"><div className="col g1"><h1 style={{ fontSize: 22 }}>Agent workflow</h1><span className="sm muted">Supplier Intelligence · 9 agents · 3 human checkpoints · runs daily at 06:00</span></div></div>
      {F && (
        <div className="alert-box" style={{ borderColor: 'var(--brand-line)', background: 'var(--brand-soft)' }}>
          <WorkflowIcon size={16} /><span style={{ flex: 1 }}>Highlighted: the agents that answered “{s.wfQ}”</span>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => mut((n) => { n.wfFocus = null; n.wfQ = '' })}>Show all</button>
        </div>
      )}
      <div className="canvas-wrap" ref={wrap} style={{ height: CH * scale }}>
        <div className="canvas" style={{ height: CH, transform: `scale(${scale})` }}>
          <div className="lane" style={{ top: 8, height: CH - 16 }}><span>Supplier Intelligence · Rail Tunnel Lot 4</span></div>
          <svg className="edges" viewBox={`0 0 ${CW} ${CH}`} style={{ height: CH }} aria-hidden="true">
            <defs>
              <marker id="ah" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" style={{ fill: 'var(--ring)' }} /></marker>
              <marker id="ah-on" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" style={{ fill: 'var(--brand)' }} /></marker>
            </defs>
            {SI_EDGES.map(([a, b, m, d]) => {
              const on = (O.ns[a] === 'done' && O.ns[b]) || (F && inF(a) && inF(b))
              return <path key={a + b} className={`edge ${d ? 'dash' : ''}`} style={on ? { stroke: 'var(--brand)', strokeWidth: 2.5 } : undefined} d={edgePath(a, b, m)} markerEnd={`url(#${on ? 'ah-on' : 'ah'})`} />
            })}
          </svg>
          {Object.entries(SI_NODES).map(([id, n]) => {
            const live = s.busyAgents[id] ? 'running' : ''
            const focus = F && !n.human ? (inF(id) ? 'focus' : 'dim') : ''
            return (
              <button type="button" key={id} className={`node ${n.human ? 'human' : ''} ${O.ns[id] || live} ${focus}`} style={{ left: n.x, top: n.y }} onClick={() => openNode(id)}>
                <span className="nt">{n.t}</span><span className="ns">{O.ns[id] === 'waiting' ? `Awaiting ${n.s}` : n.s}</span>
              </button>
            )
          })}
        </div>
      </div>
      {controls}
      <div className="panel">
        <div className="panel-h"><span className="medium">Run trace</span><span className="xs muted">Audit log of the last run</span></div>
        <div className="x-scroll">
          <table className="tbl trace" style={{ minWidth: 880 }}>
            <thead><tr><th>Time</th><th>Step</th><th>Rule version</th><th>Data read</th><th>Result / decision</th></tr></thead>
            <tbody>
              {O.trace.length === 0 && <tr><td colSpan={5} className="muted c" style={{ padding: 24 }}>Press Run now to watch the daily run step by step</td></tr>}
              {O.trace.map((e, i) => (
                <tr key={i} className={e.human ? 'h' : ''}>
                  <td className="t">{e.t}</td><td className="medium">{e.step}</td><td>{e.rule || '—'}</td><td>{e.src || '—'}</td>
                  <td>{e.out}{e.human && <span className="xs muted" style={{ display: 'block' }}>{e.human}</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
