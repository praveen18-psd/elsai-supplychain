import { useEffect, useRef, useState } from 'react'
import { ArrowUp, MessageSquare, Mic } from 'lucide-react'
import { prefersReducedMotion, wait } from '../lib/format.js'
import { useWS } from './store.jsx'

const VOICE_SCRIPT = ['Which suppliers are getting riskier?', 'Tell me about Cantieri Alfa', 'What happens if the haulage strike goes ahead?', 'What money is at risk with Cantieri Alfa?', 'Find alternatives to Cantieri Alfa', 'Compare the bids for TND-2026-014']
const HINT = 'elsai agents read your connected systems and propose actions. People approve anything binding.'

/**
 * Chat input with voice. Uses the browser's speech recognition where allowed (Chrome/Edge on https).
 * Where the microphone is unavailable it plays the next natural question as a spoken request.
 */
export default function Composer({ suggestions }) {
  const { s, ask, isBusy } = useWS()
  const [text, setText] = useState('')
  const [listening, setListening] = useState(false)
  const ta = useRef(null)
  const token = useRef(0)
  const rec = useRef(null)
  const scriptIdx = useRef(0)

  useEffect(() => { const t = ta.current; if (!t) return; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 140) + 'px' }, [text])

  const send = (v) => { const q = (v ?? text).trim(); if (!q) return; setText(''); ask(q) }

  const nextQuestion = () => {
    const last = s.msgs[s.msgs.length - 1]
    if (s.view === 'chat' && last && last.follow.length) return last.follow[0]
    return VOICE_SCRIPT[scriptIdx.current++ % VOICE_SCRIPT.length]
  }

  const playback = async (tk) => {
    const q = nextQuestion(), words = q.split(' '), reduce = prefersReducedMotion()
    setText('')
    await wait(reduce ? 100 : 900)
    for (let i = 0; i < words.length; i++) { if (token.current !== tk) return; setText(words.slice(0, i + 1).join(' ')); await wait(reduce ? 20 : 170 + Math.random() * 90) }
    await wait(reduce ? 50 : 500)
    if (token.current !== tk) return
    setListening(false); send(q)
  }

  const stop = () => { token.current++; if (rec.current) { const r = rec.current; rec.current = null; try { r.abort() } catch (e) { /* ignore */ } } setListening(false) }

  const start = () => {
    if (isBusy) return
    const tk = ++token.current
    setListening(true); setText('')
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition
    if (SR) {
      try {
        const r = new SR(); rec.current = r
        r.lang = 'en-GB'; r.interimResults = true; r.continuous = false
        let heard = ''
        r.onresult = (e) => { heard = Array.from(e.results).map((x) => x[0].transcript).join(''); setText(heard) }
        r.onerror = () => { if (rec.current !== r) return; rec.current = null; if (!heard.trim() && token.current === tk) playback(tk) }
        r.onend = () => { if (rec.current !== r) return; rec.current = null; if (token.current !== tk) return; setListening(false); if (heard.trim()) send(heard) }
        r.start(); return
      } catch (e) { rec.current = null }
    }
    playback(tk)
  }

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape' && listening) stop() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  return (
    <div className="composer-wrap">
      <form className="composer" onSubmit={(e) => { e.preventDefault(); send() }}>
        {suggestions.length > 0 && (
          <div className="followups" style={{ marginTop: 0 }}>
            {suggestions.map((q) => <button type="button" key={q} className="fu" disabled={isBusy} onClick={() => ask(q)}><MessageSquare size={13} />{q}</button>)}
          </div>
        )}
        <div className={`cbox ${listening ? 'listening' : ''}`}>
          <textarea ref={ta} rows={1} value={text} aria-label="Message elsai"
            placeholder={listening ? 'Listening…' : 'Ask elsai about any supplier, risk, contract or tender…'}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }} />
          <span className="wave" aria-hidden="true"><span /><span /><span /><span /><span /></span>
          <button type="button" className={`btn btn-outline mic ${listening ? 'on' : ''}`} aria-pressed={listening} aria-label={listening ? 'Stop listening' : 'Ask by voice'} title="Ask by voice" onClick={() => (listening ? stop() : start())}><Mic size={16} /></button>
          <button type="submit" className="btn btn-default send" disabled={isBusy} aria-label="Send"><ArrowUp size={16} /></button>
        </div>
        <div className="hint">{listening ? 'Listening… click the microphone again to stop.' : HINT}</div>
      </form>
    </div>
  )
}
