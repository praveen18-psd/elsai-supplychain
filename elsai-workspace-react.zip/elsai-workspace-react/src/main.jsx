import React, { useEffect, useState } from 'react'
import ReactDOM from 'react-dom/client'
import Workspace from './web/Workspace.jsx'
import Devices from './devices/Devices.jsx'
import { PhoneOnly, WatchOnly } from './devices/Standalone.jsx'
import './styles.css'

/** Hash routes: #/ web workspace · #/devices phone + watch demo · #/mobile phone app · #/watch watch app */
function useRoute() {
  const read = () => (window.location.hash.replace(/^#\/?/, '') || 'web').split('?')[0]
  const [route, setRoute] = useState(read)
  useEffect(() => {
    const on = () => setRoute(read())
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return route
}

function App() {
  const route = useRoute()
  if (route === 'devices') return <Devices />
  if (route === 'mobile') return <PhoneOnly />
  if (route === 'watch') return <WatchOnly />
  return <Workspace />
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
