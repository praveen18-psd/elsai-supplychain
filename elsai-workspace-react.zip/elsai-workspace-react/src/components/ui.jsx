import { UserRound } from 'lucide-react'
import { PEOPLE } from '../lib/data.js'
import { initials } from '../lib/format.js'

/** Status badge. tone: ok | warn | bad | human | solid | secondary | neutral */
export function Badge({ tone = 'neutral', children }) {
  if (tone === 'ok' || tone === 'warn' || tone === 'bad') return <span className={`badge b-${tone}`}><span className={`dot d-${tone}`} />{children}</span>
  if (tone === 'human') return <span className="badge b-human"><UserRound size={12} />{children}</span>
  return <span className={`badge ${tone === 'solid' ? 'b-solid' : tone === 'secondary' ? 'b-secondary' : ''}`}>{children}</span>
}

export function Switch({ on, onChange, label }) {
  return <button type="button" className="switch" role="switch" aria-checked={!!on} aria-label={label} onClick={onChange}><span /></button>
}

export function Owner({ who }) {
  const p = PEOPLE[who]
  return (
    <span className="owner">
      <span className="avatar sm">{initials(p.name)}</span>
      <span className="who"><span className="medium">{p.name}</span><span>{p.role}</span></span>
    </span>
  )
}

/** Small trend line; scale is the 0–100 risk range. */
export function Spark({ values, w = 96, h = 28, color = 'var(--chart-2)' }) {
  const x = (i) => 2 + (i * (w - 4)) / (values.length - 1)
  const y = (v) => h - 3 - (v / 100) * (h - 6)
  const d = values.map((v, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1)).join(' ')
  return (
    <svg className="spark" width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden="true">
      <path d={d} style={{ fill: 'none', stroke: color }} strokeWidth="1.75" />
      <circle cx={x(values.length - 1)} cy={y(values[values.length - 1])} r="2.5" style={{ fill: color }} />
    </svg>
  )
}

/** Risk score over May–Oct with the High threshold marked. */
export function TrendChart({ data }) {
  const W = 560, H = 150, l = 28, r = 12, t = 14, b = 22
  const x = (i) => l + (i * (W - l - r)) / (data.length - 1)
  const y = (v) => t + ((100 - v) / 100) * (H - t - b)
  const pts = data.map(([, v], i) => [x(i), y(v)])
  const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ')
  const tx = { fill: 'var(--muted-foreground)', font: '400 10.5px var(--font-sans)' }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto', display: 'block' }} role="img" aria-label={`Risk score May–Oct: ${data.map((p) => p[1]).join(', ')}`}>
      {[0, 60, 100].map((v) => (
        <g key={v}>
          <line x1={l} x2={W - r} y1={y(v)} y2={y(v)} style={{ stroke: 'var(--border)' }} strokeDasharray={v ? '3 3' : '0'} />
          <text x={l - 6} y={y(v) + 3} textAnchor="end" style={tx}>{v}</text>
        </g>
      ))}
      <text x={W - r} y={y(60) - 4} textAnchor="end" style={{ ...tx, fill: 'var(--bad)' }}>High ≥ 60</text>
      <path d={`${line} L ${x(data.length - 1)} ${y(0)} L ${x(0)} ${y(0)} Z`} style={{ fill: 'var(--chart-2)' }} opacity=".08" />
      <path d={line} style={{ fill: 'none', stroke: 'var(--chart-2)' }} strokeWidth="2" />
      {pts.map((p, i) => {
        const last = i === pts.length - 1
        return (
          <g key={i}>
            <circle cx={p[0]} cy={p[1]} r={last ? 4.5 : 2.5} style={{ fill: last ? 'var(--chart-2)' : 'var(--card)', stroke: 'var(--chart-2)' }} strokeWidth="2" />
            <text x={p[0]} y={H - 6} textAnchor="middle" style={tx}>{data[i][0]}</text>
            <text x={p[0]} y={p[1] - 8} textAnchor="middle" style={{ fill: 'var(--foreground)', font: '500 10.5px var(--font-sans)' }}>{data[i][1]}</text>
          </g>
        )
      })}
    </svg>
  )
}

/** elsai mark, cropped from the logo. */
export function Mark({ size = 20, style }) {
  return <span className="mark" role="img" aria-label="elsai" style={{ display: 'block', width: size, height: size, backgroundImage: 'url(/elsai-logo.png)', backgroundRepeat: 'no-repeat', backgroundPosition: 'left center', backgroundSize: `auto ${size}px`, ...style }} />
}

export function Toast({ msg }) {
  return <div id="toast" className={msg ? 'show' : ''} role="status" aria-live="polite">{msg}</div>
}
