import { useEffect, useRef, useState } from 'react'
import { ArrowUp, BatteryFull, BellRing, Check, CheckCircle2, ChevronLeft, ClipboardCheck, MessageSquare, Mic, ScanFace, Signal, Sun, Wifi } from 'lucide-react'
import { DIM_KEYS, EXPOSURE, SUPPLIERS, scoreOf, trendOf } from '../lib/data.js'
import { MOBILE_APPROVALS } from '../lib/alerts.js'
import { lvlTone, money, riskLvl, wait } from '../lib/format.js'
import { Badge, Mark, Spark, Switch } from '../components/ui.jsx'
import { pending, useDevices } from './store.jsx'

const ASK_CHIPS = ['Which suppliers are getting riskier?', 'What happens if the strike goes ahead?', 'Money at risk with Cantieri Alfa', 'Compare the bids for TND-2026-014']

function Status({ light }) {
  return <div className="status" style={light ? { color: 'oklch(1 0 0)' } : undefined}><span>9:41</span><span className="r"><Signal size={15} /><Wifi size={15} /><BatteryFull size={15} /></span></div>
}

function Notification({ n, onOpen, banner }) {
  return (
    <button type="button" className={`nf ${banner ? 'banner' : ''}`} onClick={onOpen}>
      <span className="app"><Mark size={22} /></span>
      <span>
        <span className="hd"><span>elsai</span><span>{n.t || 'now'}</span></span>
        <span className="tt" style={{ display: 'block' }}>{n.title}</span>
        <span className="bd" style={{ display: 'block' }}>{n.body}</span>
      </span>
    </button>
  )
}

function Head({ title, right }) {
  return <div className="app-head"><h2>{title}</h2>{right}</div>
}

function Today() {
  const { M, mut } = useDevices()
  const watch = [...SUPPLIERS].sort((a, b) => scoreOf(b) - scoreOf(a)).slice(0, 4)
  const alfa = EXPOSURE.filter((e) => e.sub === 'Cantieri Alfa').reduce((s, e) => s + e.amt, 0)
  const open = (id) => mut((n) => { n.sup = id })
  return (
    <>
      <Head title="Today" right={<span className="avatar sm" style={{ width: 32, height: 32 }}>MB</span>} />
      <div className="app-body">
        <div className="sm muted" style={{ marginTop: -6 }}>8 agents checked 1,240 suppliers overnight</div>
        <button type="button" className="m-card" onClick={() => open('alfa')}><span className="row between"><Badge tone="bad">Supplier risk</Badge><span className="xs muted">08:02</span></span><span className="medium">Cantieri Alfa risk rose to 68</span><span className="sm muted">Credit rating cut · 12 days late on Metro Line B</span></button>
        <button type="button" className="m-card" onClick={() => mut((n) => { n.tab = 'approvals' })}><span className="row between"><Badge tone="warn">Disruption</Badge><span className="xs muted">08:41</span></span><span className="medium">Haulage strike could stop the TBM</span><span className="sm muted">Approval waiting: move batch 4 to 10–11 Oct</span></button>
        <div className="m-kpis">
          <div className="m-kpi"><div className="v">{pending(M).length}</div><div className="l">Approvals waiting</div></div>
          <div className="m-kpi"><div className="v">1</div><div className="l">High-risk supplier</div></div>
          <div className="m-kpi"><div className="v">{money(alfa)}</div><div className="l">At risk · Alfa</div></div>
        </div>
        <div className="m-sec">Suppliers to watch</div>
        <div className="m-card" style={{ padding: '6px 14px' }}>
          {watch.map((s) => {
            const v = scoreOf(s)
            return (
              <button type="button" key={s.id} className="m-row" onClick={() => open(s.id)}>
                <span><span className="medium sm">{s.name}</span><span className="xs muted" style={{ display: 'block' }}>{s.risks[0] ? s.risks[0][1] : 'None flagged'}</span></span>
                <span className="row-2" style={{ flexWrap: 'nowrap' }}><Spark values={trendOf(s).map((p) => p[1])} w={56} h={20} color={v >= 60 ? 'var(--bad)' : 'var(--chart-2)'} /><Badge tone={lvlTone(riskLvl(v))}>{v}</Badge></span>
              </button>
            )
          })}
        </div>
      </div>
    </>
  )
}

function Supplier({ id }) {
  const { mut, ask } = useDevices()
  const s = SUPPLIERS.find((x) => x.id === id), v = scoreOf(s), lv = riskLvl(v), d = v - s.was
  const exp = EXPOSURE.filter((e) => e.sub === s.name).reduce((t, e) => t + e.amt, 0)
  return (
    <>
      <div className="app-head"><button type="button" className="back" onClick={() => mut((n) => { n.sup = null })}><ChevronLeft size={16} />Back</button><span /></div>
      <div className="app-body">
        <div className="col g1"><h2 style={{ fontSize: 22, fontWeight: 600 }}>{s.name}</h2><span className="sm muted">{s.cat} · {s.share}% of category spend</span></div>
        <div className="m-card">
          <div className="row between" style={{ alignItems: 'flex-end' }}><div><div className="big">{v}</div><div className="sm muted">{d >= 0 ? 'Up' : 'Down'} {Math.abs(d)} since July</div></div><Badge tone={lvlTone(lv)}>{lv} risk</Badge></div>
          <Spark values={trendOf(s).map((p) => p[1])} w={300} h={56} color={v >= 60 ? 'var(--bad)' : 'var(--chart-2)'} />
        </div>
        <div className="m-card">
          {DIM_KEYS.map(([k, n]) => { const x = s.dims[k], l = riskLvl(x); return <div className="d2" key={k}><span>{n}</span><span className="tr"><span className={`f-${lvlTone(l)}`} style={{ width: `${x}%` }} /></span><span className="num medium" style={{ textAlign: 'right' }}>{x}</span></div> })}
        </div>
        {s.risks.length > 0 && <div className="row-2">{s.risks.map(([t, l]) => <Badge key={l} tone={t}>{l}</Badge>)}</div>}
        {exp > 0 && <div className="m-card"><span className="sm muted">Money at risk</span><span className="big" style={{ fontSize: 28 }}>{money(exp)}</span></div>}
        <button type="button" className="btn btn-default" onClick={() => ask(`Tell me about ${s.name}`)}><MessageSquare size={16} />Ask elsai about {s.id === 'alfa' ? 'Alfa' : s.name.split(' ')[0]}</button>
        <div className="xs muted">Sources: Credit bureau feed, Compliance register, Milestone tracker · updated 07 Oct</div>
      </div>
    </>
  )
}

function Approvals() {
  const { M, mut, toast } = useDevices()
  const done = MOBILE_APPROVALS.filter((a) => M.appr[a.id])
  const list = pending(M)
  return (
    <>
      <Head title="Approvals" />
      <div className="app-body">
        {list.length ? list.map((a) => (
          <div className="m-card" key={a.id}>
            <span className="row between"><Badge tone={lvlTone(a.sev)}>{a.sev}</Badge><span className="xs muted">For you</span></span>
            <span className="medium">{a.t}</span><span className="sm muted">{a.d}</span>
            <span className="row-2">
              <button type="button" className="btn btn-default btn-sm" onClick={() => mut((n) => { n.confirm = a.id })}><Check size={16} />Approve</button>
              <button type="button" className="btn btn-outline btn-sm" onClick={() => toast('Moved to later · it stays in your approvals')}>Later</button>
            </span>
          </div>
        )) : (
          <div className="m-card" style={{ alignItems: 'center', textAlign: 'center', padding: 28 }}><CheckCircle2 size={20} /><span className="medium">You're all caught up</span><span className="sm muted">New approvals will appear here and on your watch</span></div>
        )}
        {done.length > 0 && (
          <>
            <div className="m-sec">Done today</div>
            <div className="m-card" style={{ padding: '6px 14px' }}>{done.map((a) => <div className="m-row" key={a.id} style={{ cursor: 'default' }}><span className="sm">{a.t}</span><span className="xs" style={{ color: 'var(--ok)' }}>{M.appr[a.id].via} · {M.appr[a.id].at}</span></div>)}</div>
          </>
        )}
      </div>
    </>
  )
}

function Alerts() {
  const { M, mut } = useDevices()
  const P = M.prefs
  const Row = ({ k, label, desc }) => <div className="sw-row"><span><span className="medium">{label}</span><span className="d" style={{ display: 'block' }}>{desc}</span></span><Switch on={P[k]} label={label} onChange={() => mut((n) => { n.prefs[k] = !n.prefs[k] })} /></div>
  return (
    <>
      <Head title="Alerts" />
      <div className="app-body">
        <div className="sm muted" style={{ marginTop: -6 }}>Synced with your web preferences</div>
        <div className="m-card" style={{ padding: '4px 14px' }}>
          <Row k="risk" label="Supplier risk" desc="Score reaches 60 or rises 10+ points" />
          <Row k="dis" label="Disruptions" desc="High severity and above" />
          <Row k="ten" label="Tender updates" desc="Evaluation complete, awards" />
          <Row k="appr" label="Approvals for me" desc="Always recommended" />
        </div>
        <div className="m-sec">Watch</div>
        <div className="m-card" style={{ padding: '12px 14px', gap: 10 }}>
          <span className="sm muted">Send to watch</span>
          <div className="tabs-list" role="group" aria-label="Watch alerts" style={{ width: '100%', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)' }}>
            {[['high', 'High + approvals'], ['approvals', 'Approvals'], ['all', 'Everything']].map(([k, l]) => <button type="button" key={k} aria-pressed={P.watch === k} onClick={() => mut((n) => { n.prefs.watch = k })}>{l}</button>)}
          </div>
        </div>
        <div className="m-card" style={{ padding: '4px 14px' }}><Row k="quiet" label="Quiet hours" desc="22:00–07:00 · High severity still comes through" /></div>
      </div>
    </>
  )
}

function AnswerCard({ R }) {
  const { mut } = useDevices()
  if (R.kind === 'exposure' && R.data.length) return <div className="m-card" style={{ padding: '6px 14px' }}>{R.data.map((e, i) => <div className="m-row" key={i} style={{ cursor: 'default' }}><span className="sm">{e.type}<span className="xs muted" style={{ display: 'block' }}>{e.project}</span></span><span className="num medium sm">{money(e.amt)}</span></div>)}</div>
  if (R.kind === 'strike') return <button type="button" className="m-card" onClick={() => mut((n) => { n.tab = 'approvals' })}><span className="row between"><Badge tone="bad">High</Badge><span className="xs muted">Approval waiting</span></span><span className="medium sm">Bring batch 4 forward to 10–11 Oct</span></button>
  if (R.kind === 'bids') return <div className="m-card" style={{ padding: '6px 14px' }}>{R.data.map((b) => { const d = b.naive - b.rw; return <div className="m-row" key={b.id} style={{ cursor: 'default' }}><span className="sm medium">{b.rw}. {b.name}</span>{d > 0 ? <Badge tone="ok">▲ {d}</Badge> : d < 0 ? <Badge tone="bad">▼ {-d}</Badge> : <Badge>—</Badge>}</div> })}</div>
  if (R.kind === 'supplier') { const s = R.data; return <button type="button" className="m-card" onClick={() => mut((n) => { n.sup = s.id })}><span className="row between"><span className="medium">{s.name}</span><Badge tone={lvlTone(riskLvl(scoreOf(s)))}>{scoreOf(s)}</Badge></span><span className="xs muted">Open supplier details</span></button> }
  if (R.kind === 'movers') return <div className="m-card" style={{ padding: '6px 14px' }}>{R.data.map((x) => <button type="button" key={x.id} className="m-row" onClick={() => mut((n) => { n.sup = x.id })}><span className="sm medium">{x.name}</span><Badge tone={lvlTone(riskLvl(scoreOf(x)))}>{scoreOf(x)} · ▲{scoreOf(x) - x.was}</Badge></button>)}</div>
  return null
}

function Ask() {
  const { M, ask } = useDevices()
  const body = useRef(null)
  useEffect(() => { if (body.current) body.current.scrollTop = body.current.scrollHeight }, [M.chat])
  return (
    <>
      <Head title="Ask elsai" />
      <div className="app-body" ref={body} style={{ paddingBottom: 150 }}>
        <div className="m-chat">
          {M.chat.map((m, i) => m.role === 'user' ? <div className="m-user" key={i}>{m.text}</div> : (
            <div className="m-agent" key={i}>
              {(m.steps.length > 0 || m.working) && (
                <div className="m-steps">
                  {m.steps.map(([a, w], j) => <div className="s" key={j}><CheckCircle2 size={12} /><b style={{ fontWeight: 500, color: 'var(--brand)' }}>{a}</b> · {w}</div>)}
                  {m.working && <div className="s"><span className="spin" style={{ width: 11, height: 11 }} />Working…</div>}
                </div>
              )}
              {m.R && <><div>{m.R.text}</div><AnswerCard R={m.R} /></>}
            </div>
          ))}
        </div>
        {!M.chat.length && <div className="sm muted">Ask in plain words. elsai's agents check your systems and answer with sources.</div>}
        <div className="chips-m">{ASK_CHIPS.map((q) => <button type="button" key={q} className="chip-m" onClick={() => ask(q)}>{q}</button>)}</div>
      </div>
    </>
  )
}

function Compose() {
  const { M, mut, ask } = useDevices()
  const [text, setText] = useState('')
  const voice = async () => {
    if (M.listening) return
    mut((n) => { n.listening = true })
    const q = 'Which suppliers are getting riskier?'
    await wait(600)
    let acc = ''
    for (const w of q.split(' ')) { acc = (acc + ' ' + w).trim(); setText(acc); await wait(170) }
    await wait(400)
    mut((n) => { n.listening = false }); setText(''); ask(q)
  }
  return (
    <form className="m-compose" onSubmit={(e) => { e.preventDefault(); ask(text); setText('') }}>
      <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask about suppliers, risks, tenders…" autoComplete="off" aria-label="Ask elsai" />
      <button type="button" className={`btn btn-outline mic ${M.listening ? 'on' : ''}`} aria-label="Ask by voice" onClick={voice}><Mic size={16} /></button>
      <button type="submit" className="btn btn-default" aria-label="Send"><ArrowUp size={16} /></button>
    </form>
  )
}

function Lock() {
  const { M, mut, ask } = useDevices()
  const openN = (i) => {
    const n = M.notifs[i]
    mut((d) => { d.banner = null; d.phone = 'app'; d.notifs.splice(i, 1); d.sup = null; if (n.open.sup) { d.tab = 'today'; d.sup = n.open.sup } else if (n.open.tab) d.tab = n.open.tab })
    if (n.open.ask) ask(n.open.ask)
  }
  return (
    <div className="lock">
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0 }}><Status light /></div>
      <div className="date">Wednesday 7 October</div>
      <div className="clock">9:41</div>
      <div className="stack">
        {M.notifs.length ? M.notifs.map((n, i) => <Notification key={i + n.title} n={n} onOpen={() => openN(i)} />) : <div className="sm" style={{ textAlign: 'center', opacity: 0.7 }}>No new alerts</div>}
      </div>
      <button type="button" className="unlock" style={{ background: 'none', border: 0, color: 'inherit', font: 'inherit', cursor: 'pointer' }} onClick={() => mut((n) => { n.phone = 'app'; n.tab = 'today'; n.sup = null })}>Swipe up or tap to open elsai</button>
    </div>
  )
}

/** The elsai phone app. `standalone` renders full-screen (for a real phone), otherwise inside a device frame. */
export default function Phone({ standalone = false }) {
  const { M, mut, approve, ask } = useDevices()
  const [scanning, setScanning] = useState(false)
  const n = pending(M).length
  const doApprove = async () => { setScanning(true); await wait(900); approve(M.confirm, 'Phone'); setScanning(false); mut((d) => { d.confirm = null }) }
  const openBanner = () => {
    const nf = M.notifs[M.banner]
    mut((d) => { d.banner = null; d.notifs.splice(0, 1); d.sup = null; if (nf.open.sup) { d.tab = 'today'; d.sup = nf.open.sup } else if (nf.open.tab) d.tab = nf.open.tab })
    if (nf.open.ask) ask(nf.open.ask)
  }
  const tabs = [['today', 'Today', Sun], ['ask', 'Ask', MessageSquare], ['approvals', 'Approvals', ClipboardCheck], ['alerts', 'Alerts', BellRing]]

  return (
    <div className={`screen ${standalone ? 'standalone' : ''}`}>
      {!standalone && <div className="island" />}
      {M.phone === 'lock' ? <Lock /> : (
        <>
          <Status />
          {M.sup ? <Supplier id={M.sup} /> : { today: <Today />, ask: <Ask />, approvals: <Approvals />, alerts: <Alerts /> }[M.tab]}
          {M.tab === 'ask' && !M.sup && <Compose />}
          <nav className="tabs" aria-label="App sections">
            {tabs.map(([k, l, I]) => (
              <button type="button" key={k} className="tab" aria-current={M.tab === k && !M.sup ? 'page' : undefined} onClick={() => mut((d) => { d.tab = k; d.sup = null })}>
                <I size={22} />{l}{k === 'approvals' && n > 0 && <span className="cnt">{n}</span>}
              </button>
            ))}
          </nav>
          {M.banner !== null && M.notifs[M.banner] && <Notification n={M.notifs[M.banner]} banner onOpen={openBanner} />}
          {M.confirm && (
            <>
              <div className="scrim-m" onClick={() => mut((d) => { d.confirm = null })} />
              <div className="sheet-m">
                <div className="medium" style={{ textAlign: 'center' }}>Approve this action?</div>
                <div className="sm muted" style={{ textAlign: 'center' }}>{MOBILE_APPROVALS.find((a) => a.id === M.confirm).t}</div>
                <div className={`bio ${scanning ? 'scan' : ''}`}><ScanFace size={24} /></div>
                <button type="button" className="btn btn-default btn-lg" onClick={doApprove}>Confirm with biometrics</button>
                <button type="button" className="btn btn-ghost" onClick={() => mut((d) => { d.confirm = null })}>Cancel</button>
              </div>
            </>
          )}
        </>
      )}
      {!standalone && <div className="homebar" style={M.phone === 'lock' ? { background: 'oklch(1 0 0)' } : undefined} />}
    </div>
  )
}
