import { Check, ChevronLeft, Mic } from 'lucide-react'
import { Mark } from '../components/ui.jsx'
import { pending, useDevices } from './store.jsx'

const SevDot = ({ sev }) => <span className="wsev" style={{ background: sev === 'High' ? 'oklch(.65 .22 25)' : sev === 'Medium' ? 'oklch(.78 .16 75)' : 'oklch(.7 .17 150)' }} />
const AppLine = ({ label }) => <div className="wn-app"><Mark size={16} style={{ filter: 'brightness(1.6)' }} />{label}</div>

/** The elsai watch app: face complication, alerts with one-tap approval, voice question. */
export default function Watch({ standalone = false }) {
  const { M, mut, approve, watchVoice, toast } = useDevices()
  const W = M.w
  const go = (view, extra) => mut((n) => { n.w.view = view; Object.assign(n.w, extra || {}) })
  const openOnPhone = () => {
    const nf = W.n
    mut((n) => { n.phone = 'app'; n.sup = null; if (nf?.open?.sup) { n.tab = 'today'; n.sup = nf.open.sup } else if (nf?.appr) n.tab = 'approvals'; else { n.tab = 'today'; n.sup = 'alfa' } n.w.view = 'face' })
    toast('Opened on phone')
  }
  const approveOnWatch = (id) => {
    approve(id, 'Watch'); go('done')
    setTimeout(() => mut((n) => { if (n.w.view === 'done') n.w.view = 'face' }), 1800)
  }

  let view = null
  if (W.view === 'face') view = (
    <div className="wv wface">
      <div className="wdate">WED 7</div>
      <div className="wclock">9:41</div>
      <button type="button" className="wcomp" onClick={() => go('list')}><Mark size={18} style={{ filter: 'brightness(1.6)' }} /><span><b>{pending(M).length}</b> need you</span></button>
    </div>
  )
  if (W.view === 'notif' && W.n) {
    const n = W.n, canApprove = n.appr && !M.appr[n.appr]
    view = (
      <div className="wv">
        <div className="wtime">9:41</div>
        <AppLine label="elsai · now" />
        <div className="wtitle"><SevDot sev={n.sev} />{n.w}</div>
        <div className="wbody">{n.wb}</div>
        {canApprove
          ? <><button type="button" className="wbtn p" onClick={() => approveOnWatch(n.appr)}>Approve</button><button type="button" className="wbtn s" onClick={() => go('face')}>Later</button></>
          : <><button type="button" className="wbtn s" onClick={openOnPhone}>Open on phone</button><button type="button" className="wbtn s" onClick={() => go('face')}>Dismiss</button></>}
      </div>
    )
  }
  if (W.view === 'list') view = (
    <div className="wv wlist">
      <div className="row between"><button type="button" className="back" style={{ color: 'oklch(.75 .12 285)', fontSize: 13 }} onClick={() => go('face')}><ChevronLeft size={14} />elsai</button><span className="wtime">9:41</span></div>
      <button type="button" className="wbtn s" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }} onClick={watchVoice}><Mic size={16} />Ask elsai</button>
      {pending(M).map((a) => (
        <button type="button" key={a.id} className="it" onClick={() => go('notif', { n: { sev: a.sev, w: a.t, wb: a.d, appr: a.id } })}><span className="k">Approval</span><span><SevDot sev={a.sev} />{a.t}</span></button>
      ))}
      {W.feed.map((n, i) => (
        <button type="button" key={i} className="it" onClick={() => go('notif', { n })}><span className="k">{n.t || 'now'}</span><span><SevDot sev={n.sev} />{n.w}</span></button>
      ))}
    </div>
  )
  if (W.view === 'done') view = <div className="wv wdone"><div className="ok"><Check size={34} /></div><div className="wtitle">Approved</div><div className="wbody">Logged for Marco Bellini</div></div>
  if (W.view === 'voice') view = <div className="wv wdone"><div className="wbody">Listening…</div><div className="wwave"><span /><span /><span /><span /><span /></div><div className="wbody" style={{ color: 'oklch(.98 0 0)' }}>“{W.heard}”</div></div>
  if (W.view === 'answer') view = (
    <div className="wv">
      <div className="wtime">9:41</div>
      <AppLine label="elsai" />
      <div className="wtitle">Cantieri Alfa · 68</div>
      <div className="wbody">High risk, up 27 since July. 12 days late on Metro Line B. €1.33M at risk.</div>
      <button type="button" className="wbtn s" onClick={openOnPhone}>Open on phone</button>
      <button type="button" className="wbtn s" onClick={() => go('face')}>Done</button>
    </div>
  )

  return <div className={`wscreen ${standalone ? 'standalone' : ''}`}>{view}</div>
}
