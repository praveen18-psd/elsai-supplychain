import { ArrowLeft, ClipboardCheck, Gauge, RotateCcw, Scale, Truck } from 'lucide-react'
import { Toast } from '../components/ui.jsx'
import { DeviceProvider, useDevices } from './store.jsx'
import Phone from './Phone.jsx'
import Watch from './Watch.jsx'

function Stage() {
  const { M, mut, simulate, reset, toastMsg } = useDevices()
  const sims = [['risk', 'Supplier risk', Gauge], ['dis', 'Disruption', Truck], ['ten', 'Tender update', Scale], ['appr', 'Approval', ClipboardCheck]]
  return (
    <div className="stage-bg">
      <div className="stage">
        <div className="topbar">
          <a href="#/" className="btn btn-ghost btn-sm" aria-label="Back to web workspace"><ArrowLeft size={16} /></a>
          <img className="logo-img" src="/elsai-logo.png" alt="elsai" />
          <span className="medium">Mobile and watch</span>
          <div className="sim" role="group" aria-label="Simulate an alert">
            <span className="lbl">Send an alert:</span>
            {sims.map(([k, l, I]) => <button type="button" key={k} className="btn btn-outline btn-sm" onClick={() => simulate(k)}><I size={16} />{l}</button>)}
            <button type="button" className="btn btn-ghost btn-sm" aria-label="Reset" onClick={reset}><RotateCcw size={16} /></button>
          </div>
        </div>
        <div className="devices">
          <div className="dev-col">
            <div className="phone"><Phone /></div>
            <span className="dev-cap">Phone · tap a notification to open it</span>
          </div>
          <div className="dev-col" style={{ paddingTop: 90 }}>
            <div className={`watch ${M.w.buzz ? 'buzz' : ''}`} key={M.w.buzz || 0}>
              <div className="band t" /><div className="band b" />
              <div className="case"><Watch /></div>
              <button type="button" className="crown" aria-label="Digital crown: home" onClick={() => mut((n) => { n.w.view = 'face' })} />
              <span className="side" />
            </div>
            <span className="dev-cap" style={{ marginTop: 80 }}>Watch · tap the face to see what needs you</span>
          </div>
        </div>
      </div>
      <Toast msg={toastMsg} />
    </div>
  )
}

/** Demo page: phone and watch side by side, sharing one state, with an alert simulator. */
export default function Devices() {
  return <DeviceProvider initialPhone="lock"><Stage /></DeviceProvider>
}
