import { createContext, useCallback, useContext, useRef, useState } from 'react'
import { B, EXPOSURE, RW_ORDER, SUPPLIERS, scoreOf } from '../lib/data.js'
import { MOBILE_APPROVALS, PUSH, deviceAllowed } from '../lib/alerts.js'
import { money, nowT, riskLvl, wait } from '../lib/format.js'
import { supplierFromText } from '../lib/intents.js'

/*
 * Shared state for the phone and watch apps. On the /devices demo page both devices share it,
 * so an approval on the watch shows up on the phone. In production each device would sync through the backend.
 */
export function initDevices(phone = 'lock') {
  return {
    phone, tab: 'today', sup: null, banner: null, confirm: null, chat: [], listening: false,
    notifs: [{ ...PUSH.risk, t: '08:02' }, { ...PUSH.dis, t: '08:41' }],
    appr: {},
    prefs: { risk: true, dis: true, ten: true, appr: true, watch: 'high', quiet: true },
    w: { view: 'face', n: null, feed: [{ ...PUSH.dis, t: '08:41' }, { ...PUSH.risk, t: '08:02' }], heard: '' },
  }
}

/** Short, mobile-sized answers. Returns { steps, text, kind, data }. */
export function mobileAnswer(q) {
  const l = q.toLowerCase(), s = supplierFromText(q)
  if (/money|exposure|at risk with/.test(l)) {
    const sp = s || SUPPLIERS[0], items = EXPOSURE.filter((e) => e.sub === sp.name).sort((a, b) => b.amt - a.amt), tot = items.reduce((t, e) => t + e.amt, 0)
    return { steps: [['Contract Exposure', 'Read validated contracts'], ['Contract Exposure', 'Matched advances in accounts payable']], text: items.length ? `${money(tot)} is at risk with ${sp.name}. The largest item is ${items[0].type.toLowerCase()}.` : `No open exposure with ${sp.name}.`, kind: 'exposure', data: items }
  }
  if (/strike|disruption|tbm|haulage/.test(l)) return { steps: [['Disruption Monitoring', 'Read transport notices'], ['Delivery Impact', 'Checked deliveries and buffers']], text: 'Metro Line B segment batch 4 is due 14 Oct with a 2-day buffer, so the TBM could stop on 16 Oct. Moving dispatch to 10–11 Oct avoids the strike.', kind: 'strike' }
  if (/bid|tender|tnd/.test(l)) return { steps: [['Bid Evaluation', 'Normalized payment terms'], ['Risk Scoring', 'Added supplier risk']], text: 'Gamma Precast ranks first once risk is counted. Cantieri Alfa drops from 1st on price to 3rd. Delta is held for a missing fire certificate.', kind: 'bids', data: RW_ORDER.map((id) => B[id]) }
  if (s) return { steps: [['Risk Scoring', 'Read credit, compliance and delivery data'], ['Supplier Concentration', 'Checked category spend']], text: `${s.name} is at ${scoreOf(s)} (${riskLvl(scoreOf(s))}), ${scoreOf(s) - s.was >= 0 ? 'up' : 'down'} ${Math.abs(scoreOf(s) - s.was)} since July.`, kind: 'supplier', data: s }
  if (/risk|riskier|supplier/.test(l)) return { steps: [['Risk Scoring', 'Re-scored 1,240 suppliers'], ['Supplier Concentration', 'Checked spend concentration']], text: 'Cantieri Alfa moved most since July and is the only High-risk supplier. Theta is next at 56.', kind: 'movers', data: [...SUPPLIERS].sort((a, b) => (scoreOf(b) - b.was) - (scoreOf(a) - a.was)).slice(0, 3) }
  return { steps: [], text: 'I can check supplier risk, disruptions, money at risk and tenders. Try one of the suggestions below.', kind: 'help' }
}

const Ctx = createContext(null)

export function DeviceProvider({ initialPhone = 'lock', children }) {
  const [M, setM] = useState(() => initDevices(initialPhone))
  const MRef = useRef(M)
  MRef.current = M
  const [toastMsg, setToast] = useState(null)
  const tRef = useRef(null)
  const busy = useRef(false)
  const bannerT = useRef(null)
  const mut = useCallback((fn) => setM((p) => { const n = structuredClone(p); fn(n); return n }), [])
  const toast = useCallback((m) => { setToast(m); clearTimeout(tRef.current); tRef.current = setTimeout(() => setToast(null), 2200) }, [])

  const approve = useCallback((id, via) => {
    const a = MOBILE_APPROVALS.find((x) => x.id === id)
    mut((n) => { n.appr[id] = { via, at: nowT() } })
    toast(`Approved on ${via.toLowerCase()} · ${a.t}`)
  }, [mut, toast])

  const simulate = useCallback((k) => {
    const a = { ...PUSH[k], t: 'now' }
    const allowed = deviceAllowed(a, MRef.current.prefs)
    if (!allowed.phone && !allowed.watch) { toast('Muted by your alert preferences'); return }
    mut((n) => {
      if (allowed.phone) { n.notifs.unshift(a); if (n.phone === 'app') n.banner = 0 }
      if (allowed.watch) { n.w.feed.unshift(a); n.w.n = a; n.w.view = 'notif'; n.w.buzz = (n.w.buzz || 0) + 1 }
    })
    if (allowed.phone && !allowed.watch) toast('Sent to phone only (watch rule)')
    clearTimeout(bannerT.current)
    bannerT.current = setTimeout(() => mut((n) => { n.banner = null }), 4200)
  }, [mut, toast])

  const ask = useCallback(async (raw) => {
    const q = raw.trim()
    if (!q || busy.current) return
    busy.current = true
    const R = mobileAnswer(q), id = 'a' + Date.now()
    mut((n) => { n.sup = null; n.tab = 'ask'; n.phone = 'app'; n.chat.push({ role: 'user', text: q }); n.chat.push({ role: 'agent', id, steps: [], working: true, R: null }) })
    for (const st of R.steps) { await wait(550); mut((n) => { n.chat.find((m) => m.id === id).steps.push(st) }) }
    await wait(350)
    mut((n) => { const m = n.chat.find((x) => x.id === id); m.working = false; m.R = R })
    busy.current = false
  }, [mut])

  const watchVoice = useCallback(async () => {
    mut((n) => { n.w.view = 'voice'; n.w.heard = '' })
    await wait(700)
    for (const w of 'How risky is Cantieri Alfa?'.split(' ')) { mut((n) => { if (n.w.view === 'voice') n.w.heard = (n.w.heard + ' ' + w).trim() }); await wait(220) }
    await wait(700)
    mut((n) => { if (n.w.view === 'voice') n.w.view = 'answer' })
  }, [mut])

  const value = { M, mut, toast, toastMsg, approve, simulate, ask, watchVoice, reset: () => setM(initDevices(initialPhone)) }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export const useDevices = () => useContext(Ctx)
export const pending = (M) => MOBILE_APPROVALS.filter((a) => !M.appr[a.id])
