import { Toast } from '../components/ui.jsx'
import { DeviceProvider, useDevices } from './store.jsx'
import Phone from './Phone.jsx'
import Watch from './Watch.jsx'

function WithToast({ children }) {
  const { toastMsg } = useDevices()
  return <>{children}<Toast msg={toastMsg} /></>
}

/** #/mobile: the phone app full-screen, for opening on a real phone. */
export function PhoneOnly() {
  return <DeviceProvider initialPhone="app"><WithToast><Phone standalone /></WithToast></DeviceProvider>
}

/** #/watch: the watch app full-screen, for a small screen or a watch browser. */
export function WatchOnly() {
  return <DeviceProvider initialPhone="app"><WithToast><Watch standalone /></WithToast></DeviceProvider>
}
