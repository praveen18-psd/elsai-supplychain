# elsai Agent Workspace (React)

Clickable prototype of elsai Supplier Intelligence as an agentic application: a web workspace plus
phone and watch apps. Scenario: Rail Tunnel Lot 4, Cantieri Alfa. All companies, people and figures are fictional.

## Run

Requires Node.js 18 or later.

```bash
npm install
npm run dev
```

| URL | What it shows |
| --- | --- |
| `http://localhost:5173/#/` | Web workspace: morning briefing, chat with live agent steps and orchestration map, agent workflow with run trace, alerts & devices preferences |
| `http://localhost:5173/#/devices` | Phone and watch side by side with an alert simulator (they share state: approve on the watch, it updates on the phone) |
| `http://localhost:5173/#/mobile` | Phone app full-screen, for opening on a real phone |
| `http://localhost:5173/#/watch` | Watch app full-screen, for a small screen |

`npm run build` writes a static build to `dist/` (host it anywhere, e.g. Netlify). Real speech input in the
web workspace needs Chrome or Edge on https; elsewhere the microphone plays a sample question.

## Structure

```text
src/
  main.jsx                 hash routes: web, devices, mobile, watch
  styles.css               shadcn/ui (new-york-v4) tokens and components, light theme, device frames
  lib/
    data.js                synthetic suppliers, contracts, sources, workflow graph (SI_NODES / SI_STEPS / SI_TR)
    intents.js             question routing, agent steps, answers, proposed actions (the orchestrator stand-in)
    alerts.js              alert preferences, delivery rules for phone / watch / digest, push content
    format.js              formatting helpers
  components/ui.jsx        Badge, Switch, Owner, Spark, TrendChart, Mark, Toast
  web/
    store.jsx              workspace state: conversation run, approvals, workflow run, preferences
    Workspace.jsx          layout: sidebar, header, panel toggles, side sheet
    Briefing.jsx           morning briefing
    Chat.jsx               messages, agent steps, orchestration map
    Answers.jsx            rich answer blocks per intent
    Composer.jsx           chat input with voice
    Workflow.jsx           agent workflow canvas, run controls, run trace
    Prefs.jsx              alerts & devices preferences with live delivery preview
    Rail.jsx               activity / agents / sources rail
    common.jsx             agent chips, source citations, action cards, detail sheets
  devices/
    store.jsx              shared phone + watch state and mobile answers
    Phone.jsx              lock screen, Today, supplier detail, Ask, Approvals, Alerts
    Watch.jsx              face, alert with one-tap approve, list, voice answer
    Devices.jsx            framed demo page with alert simulator
    Standalone.jsx         full-screen phone / watch routes
public/elsai-logo.png
```

## Where to connect real services

- `lib/intents.js`: replace keyword routing and canned answers with calls to the agent orchestrator.
- `web/store.jsx` → `approve` / `confirmReject`: post decisions to the approvals API (they are logged in the activity rail today).
- `lib/alerts.js` → `deliver`: evaluate preferences server-side before sending push notifications to phone and watch.
- `devices/store.jsx`: replace shared in-memory state with push notifications and an API sync.

State lives in memory only; refreshing a page resets it.
